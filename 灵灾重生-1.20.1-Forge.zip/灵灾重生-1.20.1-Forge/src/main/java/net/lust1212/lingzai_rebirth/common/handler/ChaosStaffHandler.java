package net.lust1212.lingzai_rebirth.common.handler;

import com.sammy.malum.common.capability.MalumPlayerDataCapability;
import com.sammy.malum.common.item.curiosities.weapons.staff.AbstractStaffItem;
import com.sammy.malum.registry.client.ParticleRegistry;
import com.sammy.malum.visual_effects.networked.data.ColorEffectData;
import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.lust1212.lingzai_rebirth.common.item.UnwindingChaosStaffItem;
import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.lust1212.lingzai_rebirth.registry.ModParticleEffectTypes;
import net.lust1212.lingzai_rebirth.registry.ModSounds;
import net.lust1212.lingzai_rebirth.visual_effects.UnwindingChaosChargeParticleEffect;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import team.lodestar.lodestone.helpers.RandomHelper;
import team.lodestar.lodestone.helpers.SoundHelper;
import team.lodestar.lodestone.registry.common.tag.LodestoneDamageTypeTags;

@Mod.EventBusSubscriber(modid = SpiritCalamityRebirth.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ChaosStaffHandler {

    @SubscribeEvent
    public static void onLivingDamage(LivingDamageEvent event) {
        if (!(event.getEntity().level() instanceof ServerLevel level)) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)) {
            return;
        }
        ItemStack stack = attacker.getMainHandItem();
        if (!stack.is(ModItems.UNWINDING_CHAOS.get())) {
            return;
        }
        LivingEntity target = event.getEntity();
        var source = event.getSource();
        if (source.is(DamageTypeTags.IS_FIRE)) {
            addStaffCharges(level, attacker, target, 40);
        }
        if (source.is(LodestoneDamageTypeTags.CAN_TRIGGER_MAGIC)) {
            target.setSecondsOnFire(5);
            if (attacker instanceof Player player) {
                for (int i = 0; i < 3; i++) {
                    AbstractStaffItem.spawnSweepParticles(player, ParticleRegistry.STAFF_SLAM_PARTICLE.get());
                }
            }
            SoundHelper.playSound(attacker, ModSounds.WORLDSOUL_MOTIF_HEAVY_IMPACT.get(), 2f, RandomHelper.randomBetween(level.random, 0.75f, 2f));
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getEntity().level() instanceof ServerLevel level)) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)) {
            return;
        }
        if (!attacker.getMainHandItem().is(ModItems.UNWINDING_CHAOS.get())) {
            return;
        }
        LivingEntity target = event.getEntity();
        if (target instanceof Player) {
            return;
        }
        if (target.isOnFire()) {
            addStaffCharges(level, attacker, target, 160);
        }
    }

    private static void addStaffCharges(ServerLevel level, LivingEntity attacker, LivingEntity target, int chargeTicks) {
        if (attacker instanceof Player player) {
            var capability = MalumPlayerDataCapability.getCapability(player);
            int gained = Math.max(1, chargeTicks / 40);
            capability.reserveStaffChargeHandler.chargeCount = Math.min(8, capability.reserveStaffChargeHandler.chargeCount + gained);
        }
        SoundHelper.playSound(attacker, ModSounds.WORLDSOUL_MOTIF_LIGHT_IMPACT.get(), 1.5f, RandomHelper.randomBetween(level.random, 0.75f, 1.25f));
        var spirit = UnwindingChaosStaffItem.getUnwindingChaosSpirit();
        ModParticleEffectTypes.UNWINDING_CHAOS_CHARGE.createEntityEffect(target,
                new ColorEffectData(spirit),
                UnwindingChaosChargeParticleEffect.createData(attacker.getId(), spirit));
    }
}