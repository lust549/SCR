package net.lust1212.lingzai_rebirth.common.handler;

import com.sammy.malum.common.capability.MalumLivingEntityDataCapability;
import com.sammy.malum.core.handlers.SoulDataHandler;
import com.sammy.malum.core.handlers.SpiritHarvestHandler;
import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.lust1212.lingzai_rebirth.common.entity.FlyingSwordEntity;
import net.lust1212.lingzai_rebirth.common.entity.SunderingAnchorProjectile;
import net.lust1212.lingzai_rebirth.common.item.SoulOfTheAnchorItem;
import net.lust1212.lingzai_rebirth.common.spirit.SpiritStorage;
import net.lust1212.lingzai_rebirth.registry.ModDamageTypes;
import net.lust1212.lingzai_rebirth.registry.ModEnchantments;
import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = SpiritCalamityRebirth.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class SpiritStorageHandler {

    private static final String DISABLED_ITEM_KEY = "item";

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.isCanceled()) {
            return;
        }
        LivingEntity target = event.getEntity();
        if (target instanceof Player || !(target.level() instanceof ServerLevel level)) {
            return;
        }
        DamageSource source = event.getSource();
        if (!(source.getEntity() instanceof LivingEntity attacker) || attacker == target) {
            return;
        }
        if (!isAnchorKill(source, attacker)) {
            return;
        }
        ItemStack anchor = findAnchorStack(level, source, attacker);
        if (anchor.isEmpty() || anchor.getEnchantmentLevel(ModEnchantments.SPIRIT_STORAGE.get()) <= 0) {
            return;
        }
        SoulDataHandler soulData = MalumLivingEntityDataCapability.getCapability(target).soulData;
        if (soulData.soulless || soulData.exposedSoulDuration <= 0) {
            return;
        }
        List<ItemStack> spirits = new ArrayList<>();
        for (ItemStack stack : SpiritHarvestHandler.getSpiritDropsRaw(target)) {
            spirits.add(stack.copy());
        }
        if (spirits.isEmpty()) {
            return;
        }
        SpiritHarvestHandler.applySpiritLootBonuses(spirits, attacker, anchor.copy());
        if (absorb(level, source, attacker, spirits)) {
            soulData.soulless = true;
        }
    }

    public static void storeForPlayer(ServerPlayer player, SpiritStorage storage) {
        var inventory = player.getInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (!(stack.getItem() instanceof SoulOfTheAnchorItem)) {
                continue;
            }
            CompoundTag tag = stack.getTag();
            if (tag == null || !tag.contains(DISABLED_ITEM_KEY)) {
                continue;
            }
            tag.getCompound(DISABLED_ITEM_KEY).put(SpiritStorage.TAG_KEY, storage.toTag());
            return;
        }
        ItemStack mainHand = player.getMainHandItem();
        if (mainHand.is(ModItems.SUNDERING_ANCHOR.get())) {
            storage.write(mainHand);
        }
    }

    private static boolean isAnchorKill(DamageSource source, LivingEntity attacker) {
        Entity direct = source.getDirectEntity();
        if (direct instanceof SunderingAnchorProjectile || direct instanceof FlyingSwordEntity) {
            return true;
        }
        if (source.is(ModDamageTypes.SUNDERING_ANCHOR_COMBO)
                || source.is(ModDamageTypes.SUNDERING_ANCHOR_MAGIC_COMBO)
                || source.is(ModDamageTypes.PIERCING_STRIKE)
                || source.is(ModDamageTypes.ANCHOR_THROW_STRIKE)
                || source.is(ModDamageTypes.ANCHOR_THROW_MAGIC_STRIKE)
                || source.is(ModDamageTypes.OVERLIMIT_STRIKE)
                || source.is(ModDamageTypes.OVERLIMIT_MAGIC_STRIKE)) {
            return true;
        }
        return direct == attacker && source.is(DamageTypes.PLAYER_ATTACK)
                && attacker.getMainHandItem().is(ModItems.SUNDERING_ANCHOR.get());
    }

    private static ItemStack findAnchorStack(ServerLevel level, DamageSource source, LivingEntity attacker) {
        Entity direct = source.getDirectEntity();
        if (direct instanceof SunderingAnchorProjectile projectile) {
            return projectile.getItem();
        }
        if (direct instanceof FlyingSwordEntity sword) {
            return sword.getItem();
        }
        ItemStack mainHand = attacker.getMainHandItem();
        if (mainHand.is(ModItems.SUNDERING_ANCHOR.get())) {
            return mainHand;
        }
        SunderingAnchorProjectile inFlight = findInFlightProjectile(level, attacker);
        return inFlight != null ? inFlight.getItem() : ItemStack.EMPTY;
    }

    private static boolean absorb(ServerLevel level, DamageSource source, LivingEntity attacker, List<ItemStack> spirits) {
        Entity direct = source.getDirectEntity();
        if (direct instanceof SunderingAnchorProjectile projectile) {
            projectile.absorbSpirits(spirits);
            return true;
        }
        if (direct instanceof FlyingSwordEntity sword && sword.getItem().is(ModItems.SUNDERING_ANCHOR.get())) {
            SpiritStorage storage = SpiritStorage.read(sword.getItem());
            storage.addSpirits(spirits);
            storage.write(sword.getItem());
            return true;
        }
        SunderingAnchorProjectile inFlight = findInFlightProjectile(level, attacker);
        if (inFlight != null) {
            inFlight.absorbSpirits(spirits);
            return true;
        }
        ItemStack mainHand = attacker.getMainHandItem();
        if (mainHand.is(ModItems.SUNDERING_ANCHOR.get())) {
            SpiritStorage storage = SpiritStorage.read(mainHand);
            storage.addSpirits(spirits);
            storage.write(mainHand);
            return true;
        }
        return false;
    }

    private static SunderingAnchorProjectile findInFlightProjectile(ServerLevel level, LivingEntity attacker) {
        if (!(attacker instanceof ServerPlayer player)) {
            return null;
        }
        List<SunderingAnchorProjectile> projectiles = level.getEntitiesOfClass(SunderingAnchorProjectile.class,
                player.getBoundingBox().inflate(160), projectile -> player.equals(projectile.getOwner()));
        SunderingAnchorProjectile fallback = null;
        for (SunderingAnchorProjectile projectile : projectiles) {
            if (!projectile.isClone()) {
                return projectile;
            }
            fallback = projectile;
        }
        return fallback;
    }
}