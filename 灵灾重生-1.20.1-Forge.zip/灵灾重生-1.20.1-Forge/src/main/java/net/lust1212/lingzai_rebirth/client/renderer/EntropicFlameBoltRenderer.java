package net.lust1212.lingzai_rebirth.client.renderer;

import com.sammy.malum.client.renderer.entity.bolt.AbstractBoltEntityRenderer;
import com.sammy.malum.common.entity.nitrate.EthericNitrateEntity;
import net.lust1212.lingzai_rebirth.common.entity.bolt.EntropicFlameBolt;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

public class EntropicFlameBoltRenderer extends AbstractBoltEntityRenderer<EntropicFlameBolt> {

    public EntropicFlameBoltRenderer(EntityRendererProvider.Context context) {
        super(context, EthericNitrateEntity.AURIC_YELLOW, EthericNitrateEntity.AURIC_PURPLE);
    }
}