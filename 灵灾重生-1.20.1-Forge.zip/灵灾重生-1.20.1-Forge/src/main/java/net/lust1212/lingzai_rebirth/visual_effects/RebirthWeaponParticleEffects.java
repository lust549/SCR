package net.lust1212.lingzai_rebirth.visual_effects;

import com.sammy.malum.client.SpiritBasedParticleBuilder;
import com.sammy.malum.core.systems.spirit.MalumSpiritType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.registries.RegistryObject;
import team.lodestar.lodestone.helpers.RandomHelper;
import team.lodestar.lodestone.systems.particle.ParticleEffectSpawner;
import team.lodestar.lodestone.systems.particle.SimpleParticleOptions;
import team.lodestar.lodestone.systems.particle.builder.WorldParticleBuilder;
import team.lodestar.lodestone.systems.particle.data.GenericParticleData;
import team.lodestar.lodestone.systems.particle.world.options.WorldParticleOptions;
import team.lodestar.lodestone.systems.particle.world.type.LodestoneWorldParticleType;

@OnlyIn(Dist.CLIENT)
public class RebirthWeaponParticleEffects {

    public static ParticleEffectSpawner spawnSlashParticle(Level level, Vec3 pos, MalumSpiritType spirit, RegistryObject<LodestoneWorldParticleType> particle) {
        var builder = SpiritBasedParticleBuilder.createSpirit(new WorldParticleOptions(particle)).setSpirit(spirit);
        var rand = level.getRandom();
        final WorldParticleBuilder worldParticleBuilder = builder
                .setScaleData(GenericParticleData.create(RandomHelper.randomBetween(rand, 1.5f, 2f)).build())
                .setTransparencyData(GenericParticleData.create(1f, 0.9f).build())
                .setSpritePicker(SimpleParticleOptions.ParticleSpritePicker.WITH_AGE)
                .setLifetime(5)
                .enableNoClip();
        return new ParticleEffectSpawner(level, pos, worldParticleBuilder);
    }
}