package net.lust1212.lingzai_rebirth.common.entity.bolt;

import com.sammy.malum.common.entity.bolt.AbstractBoltProjectileEntity;
import com.sammy.malum.common.entity.nitrate.EthericNitrateEntity;
import com.sammy.malum.visual_effects.SpiritLightSpecs;
import com.sammy.malum.visual_effects.networked.ParticleEffectType;
import net.lust1212.lingzai_rebirth.common.item.UnwindingChaosStaffItem;
import net.lust1212.lingzai_rebirth.registry.ModEntities;
import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.lust1212.lingzai_rebirth.registry.ModParticleEffectTypes;
import net.lust1212.lingzai_rebirth.registry.ModParticles;
import net.lust1212.lingzai_rebirth.registry.ModSounds;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import team.lodestar.lodestone.handlers.RenderHandler;
import team.lodestar.lodestone.systems.easing.Easing;
import team.lodestar.lodestone.systems.particle.builder.WorldParticleBuilder;
import team.lodestar.lodestone.systems.particle.data.GenericParticleData;
import team.lodestar.lodestone.systems.particle.data.color.ColorParticleData;
import team.lodestar.lodestone.systems.particle.render_types.LodestoneWorldParticleRenderType;
import team.lodestar.lodestone.systems.particle.world.LodestoneWorldParticle;
import team.lodestar.lodestone.systems.particle.world.behaviors.components.SparkBehaviorComponent;

import java.util.function.Consumer;

public class EntropicFlameBolt extends AbstractBoltProjectileEntity {

    public EntropicFlameBolt(EntityType<? extends AbstractBoltProjectileEntity> entityType, Level level) {
        super(entityType, level);
        noPhysics = false;
    }

    public EntropicFlameBolt(Level level, double x, double y, double z) {
        this(ModEntities.ENTROPIC_FLAME_BOLT.get(), level);
        setPos(x, y, z);
        noPhysics = false;
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        final AABB boundingBox = getBoundingBox();
        setBoundingBox(boundingBox.deflate(0.25f));
        HitResult hitResult = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
        if (hitResult instanceof BlockHitResult blockHitResult) {
            super.onHitBlock(blockHitResult);
        }
        setBoundingBox(boundingBox);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if (fadingAway || spawnDelay > 0) {
            return;
        }
        if (result.getEntity() instanceof LivingEntity livingEntity) {
            livingEntity.setSecondsOnFire(4);
        }
        super.onHitEntity(result);
    }

    @Override
    public void playSound(SoundEvent sound, float volume, float pitch) {
        super.playSound(sound, volume, pitch - 0.2f);
        super.playSound(ModSounds.WORLDSOUL_MOTIF_LIGHT_IMPACT.get(), volume - 0.2f, pitch + 0.5f);
        super.playSound(ModSounds.WORLDSOUL_MOTIF_REVERB.get(), volume - 0.2f, pitch + 0.5f);
    }

    @Override
    public int getMaxAge() {
        return 60;
    }

    @Override
    public ParticleEffectType getImpactParticleEffect() {
        return ModParticleEffectTypes.ENTROPIC_BOLT_IMPACT;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.UNWINDING_CHAOS.get();
    }

    @OnlyIn(Dist.CLIENT)
    @Override
    public void spawnParticles() {
        Level level = level();
        Vec3 position = position();
        float scalar = getVisualEffectScalar();
        Vec3 norm = getDeltaMovement().normalize().scale(0.05f);
        var lightSpecs = SpiritLightSpecs.spiritLightSpecs(level, position, UnwindingChaosStaffItem.AURIC_COLOR_DATA);
        lightSpecs.getBuilder()
                .setRenderTarget(RenderHandler.LATE_DELAYED_RENDER)
                .multiplyLifetime(2.5f)
                .setRenderType(LodestoneWorldParticleRenderType.LUMITRANSPARENT)
                .enableForcedSpawn()
                .setMotion(norm);
        lightSpecs.getBloomBuilder()
                .setRenderTarget(RenderHandler.LATE_DELAYED_RENDER)
                .multiplyLifetime(1.5f)
                .setRenderType(LodestoneWorldParticleRenderType.LUMITRANSPARENT)
                .setMotion(norm);
        lightSpecs.spawnParticles();

        final Consumer<LodestoneWorldParticle> behavior = p -> p.setParticleSpeed(p.getParticleSpeed().scale(0.98f));
        final float min = Math.min(1f, 2 * scalar);
        WorldParticleBuilder.create(ModParticles.GIANT_ARROW, new SparkBehaviorComponent(GenericParticleData.create(1.8f * scalar, 0.2f * scalar).setEasing(Easing.CUBIC_IN).build()))
                .setRenderTarget(RenderHandler.LATE_DELAYED_RENDER)
                .setTransparencyData(GenericParticleData.create(0.5f * min, 0f).setEasing(Easing.SINE_IN_OUT, Easing.SINE_IN).build())
                .setScaleData(GenericParticleData.create(1.2f * scalar, 0.1f * scalar).setEasing(Easing.SINE_IN_OUT).build())
                .setColorData(UnwindingChaosStaffItem.AURIC_COLOR_DATA)
                .setLifetime(Math.min(2 + age, 16))
                .addTickActor(behavior)
                .enableForcedSpawn()
                .setMotion(norm)
                .enableNoClip()
                .spawn(level, position.x, position.y, position.z)
                .setRenderType(LodestoneWorldParticleRenderType.LUMITRANSPARENT)
                .setColorData(ColorParticleData.create(EthericNitrateEntity.AURIC_YELLOW, EthericNitrateEntity.AURIC_YELLOW).setCoefficient(3f).build())
                .setScaleData(GenericParticleData.create(1.5f * scalar, 0.3f * scalar).setEasing(Easing.SINE_IN_OUT).build())
                .setTransparencyData(GenericParticleData.create(0.6f * min, 0.3f * min, 0f).setEasing(Easing.SINE_IN_OUT, Easing.SINE_IN).build())
                .setLifetime(Math.min(3 + age, 24))
                .setMotion(norm.scale(0.5f))
                .spawn(level, position.x, position.y, position.z);
    }
}