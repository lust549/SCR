package net.lust1212.lingzai_rebirth.visual_effects;

import com.sammy.malum.client.PointyDirectionalBehaviorComponent;
import com.sammy.malum.core.systems.spirit.MalumSpiritType;
import com.sammy.malum.visual_effects.networked.ParticleEffectType;
import net.lust1212.lingzai_rebirth.registry.ModParticles;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import team.lodestar.lodestone.helpers.RandomHelper;
import team.lodestar.lodestone.systems.particle.data.GenericParticleData;
import team.lodestar.lodestone.systems.particle.data.spin.SpinParticleData;

import java.util.function.Supplier;

public class SunderingAnchorSweepParticleEffect extends ParticleEffectType {

    public SunderingAnchorSweepParticleEffect(String id) {
        super(id);
    }

    public static com.sammy.malum.visual_effects.networked.data.NBTEffectData createData(MalumSpiritType spiritType) {
        net.minecraft.nbt.CompoundTag tag = new net.minecraft.nbt.CompoundTag();
        tag.putString("spiritType", spiritType.identifier);
        return new com.sammy.malum.visual_effects.networked.data.NBTEffectData(tag);
    }

    @OnlyIn(Dist.CLIENT)
    @Override
    public Supplier<ParticleEffectActor> get() {
        return () -> (level, random, positionData, colorData, nbtData) -> {
            float angle = random.nextFloat() * 6.28f;
            Vec3 direction = new Vec3(Mth.sin(angle), 0, Mth.cos(angle));
            MalumSpiritType spirit = nbtData == null ? com.sammy.malum.registry.common.SpiritTypeRegistry.INFERNAL_SPIRIT
                    : SunderingAnchorSlashParticleEffect.getSpiritType(nbtData.compoundTag);

            var particle = random.nextBoolean() ? ModParticles.THIN_ROUNDABOUT_SLASH : ModParticles.ROUNDABOUT_SLASH;
            var slash = RebirthWeaponParticleEffects.spawnSlashParticle(level, positionData.getAsVector(), spirit, particle);
            int lifetime = (int) RandomHelper.randomBetween(random, 8, 12);
            int directionScalar = random.nextBoolean() ? -1 : 1;
            slash.getBuilder()
                    .setSpinData(SpinParticleData.create(0).randomSpinOffset(random).build())
                    .setLifetime(lifetime)
                    .setScaleData(GenericParticleData.create(RandomHelper.randomBetween(random, 2f, 3f)).build())
                    .setMotion(direction.scale(RandomHelper.randomBetween(random, 0.02f, 0.05f)))
                    .setRandomOffset(0.5f)
                    .setBehavior(new PointyDirectionalBehaviorComponent(direction.scale(directionScalar)));
            slash.spawnParticles();
            slash.getBuilder()
                    .setTransparencyData(GenericParticleData.create(0.6f, 0.3f).build())
                    .setScaleData(GenericParticleData.create(RandomHelper.randomBetween(random, 1.5f, 2f)).build())
                    .setLifeDelay(lifetime);
            slash.spawnParticles();
            slash.getBuilder()
                    .setTransparencyData(GenericParticleData.create(0.3f, 0f).build())
                    .setScaleData(GenericParticleData.create(RandomHelper.randomBetween(random, 1.2f, 1.6f)).build())
                    .setLifeDelay(lifetime * 2);
            slash.spawnParticles();
        };
    }
}