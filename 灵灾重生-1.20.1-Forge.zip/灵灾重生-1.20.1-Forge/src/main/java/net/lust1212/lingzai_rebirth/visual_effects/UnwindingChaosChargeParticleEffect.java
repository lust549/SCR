package net.lust1212.lingzai_rebirth.visual_effects;

import com.sammy.malum.core.systems.spirit.MalumSpiritType;
import com.sammy.malum.registry.common.SpiritTypeRegistry;
import com.sammy.malum.visual_effects.SpiritLightSpecs;
import com.sammy.malum.visual_effects.networked.ParticleEffectType;
import com.sammy.malum.visual_effects.networked.data.NBTEffectData;
import net.lust1212.lingzai_rebirth.registry.ModParticles;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import team.lodestar.lodestone.handlers.RenderHandler;
import team.lodestar.lodestone.helpers.RandomHelper;
import team.lodestar.lodestone.systems.easing.Easing;
import team.lodestar.lodestone.systems.particle.builder.WorldParticleBuilder;
import team.lodestar.lodestone.systems.particle.data.GenericParticleData;
import team.lodestar.lodestone.systems.particle.data.color.ColorParticleData;
import team.lodestar.lodestone.systems.particle.render_types.LodestoneWorldParticleRenderType;
import team.lodestar.lodestone.systems.particle.world.LodestoneWorldParticle;
import team.lodestar.lodestone.systems.particle.world.behaviors.components.SparkBehaviorComponent;

import java.awt.Color;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class UnwindingChaosChargeParticleEffect extends ParticleEffectType {

    public UnwindingChaosChargeParticleEffect(String id) {
        super(id);
    }

    public static NBTEffectData createData(int entityId, MalumSpiritType spiritType) {
        CompoundTag tag = new CompoundTag();
        tag.putInt("entityId", entityId);
        tag.putString("spiritType", spiritType.identifier);
        return new NBTEffectData(tag);
    }

    @OnlyIn(Dist.CLIENT)
    @Override
    public Supplier<ParticleEffectActor> get() {
        return () -> (level, random, positionData, colorData, nbtData) -> {
            CompoundTag tag = nbtData.compoundTag;
            Entity entity = level.getEntity(tag.getInt("entityId"));
            if (entity == null) {
                return;
            }
            MalumSpiritType spirit = SpiritTypeRegistry.SPIRITS.get(tag.getString("spiritType"));
            if (spirit == null) {
                spirit = SpiritTypeRegistry.AQUEOUS_SPIRIT;
            }
            var smokeColor = new Color(45, 15, 15);
            var pos = positionData.getAsVector();
            var direction = pos.subtract(entity.position()).normalize();
            float yRot = ((float) (Mth.atan2(direction.x, direction.z) * (double) (180F / (float) Math.PI)));
            float yaw = (float) Math.toRadians(yRot);
            Vec3 left = new Vec3(-Math.cos(yaw), 0, Math.sin(yaw));
            Vec3 up = left.cross(direction);

            Consumer<LodestoneWorldParticle> behavior = p -> {
                Vec3 distance = entity.position().add(0, entity.getBbHeight() / 2f, 0).subtract(p.getParticlePosition());
                float delta = Mth.clamp(p.getAge() / 20f, 0f, 1f);
                float lerp = 0.05f + 0.45f * delta;
                float velocity = 0.05f + (0.2f + (float) distance.length() * 1.2f) * delta;
                final Vec3 speed = p.getParticleSpeed().lerp(distance.normalize().scale(velocity), lerp);
                p.setParticleSpeed(speed);
            };

            for (int i = 0; i < 16; i++) {
                float spread = RandomHelper.randomBetween(random, 0.5f, 0.6f);
                float speed = RandomHelper.randomBetween(random, 0.6f, 0.8f);
                float angle = i / 16f * (float) Math.PI * 2f;
                Vec3 particleDirection = direction
                        .add(left.scale(Math.sin(angle) * spread))
                        .add(up.scale(Math.cos(angle) * spread))
                        .normalize().scale(speed);
                Vec3 particlePosition = pos.add(particleDirection.scale(2f));

                var lightSpecs = SpiritLightSpecs.spiritLightSpecs(level, particlePosition, spirit);
                var transparencyData = GenericParticleData.create(0.4f, 0.8f, 0f).setEasing(Easing.SINE_IN_OUT, Easing.EXPO_IN_OUT).build();
                int lifeDelay = i * 2;
                lightSpecs.getBuilder()
                        .setTransparencyData(transparencyData)
                        .setLifeDelay(lifeDelay)
                        .setLifetime(20)
                        .addTickActor(behavior);
                lightSpecs.getBloomBuilder()
                        .setTransparencyData(transparencyData)
                        .setLifeDelay(lifeDelay)
                        .setLifetime(20)
                        .addTickActor(behavior);
                lightSpecs.spawnParticles();

                WorldParticleBuilder.create(ModParticles.GIANT_ARROW, new SparkBehaviorComponent(GenericParticleData.create(0.2f, 2f, 0f).setEasing(Easing.SINE_IN, Easing.SINE_IN_OUT).build()))
                        .setRenderType(LodestoneWorldParticleRenderType.LUMITRANSPARENT)
                        .setRenderTarget(RenderHandler.LATE_DELAYED_RENDER)
                        .setColorData(ColorParticleData.create(smokeColor).build())
                        .setTransparencyData(GenericParticleData.create(1f, 0f).build())
                        .setScaleData(GenericParticleData.create(RandomHelper.randomBetween(random, 2, 2.5f)).build())
                        .setLifeDelay(lifeDelay)
                        .setLifetime(20)
                        .addTickActor(behavior)
                        .spawn(level, particlePosition.x, particlePosition.y, particlePosition.z);
            }
        };
    }
}