package net.lust1212.lingzai_rebirth.common.enchantment;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

public class OverlimitEnchantment extends LegendaryAnchorEnchantment {

    @Override
    public Component getFullname(int level) {
        return Component.translatable(getDescriptionId()).withStyle(ChatFormatting.RED);
    }
}