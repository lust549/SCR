package net.lust1212.lingzai_rebirth.registry;

import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMobEffects {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, SpiritCalamityRebirth.MOD_ID);

    public static final RegistryObject<MobEffect> HATRED = EFFECTS.register("hatred",
            () -> new MobEffect(MobEffectCategory.HARMFUL, 0x6d1b2e) {
            });
}