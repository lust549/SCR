package net.lust1212.lingzai_rebirth.client;

import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.lust1212.lingzai_rebirth.client.renderer.EntropicFlameBoltRenderer;
import net.lust1212.lingzai_rebirth.client.renderer.FlyingSwordRenderer;
import net.lust1212.lingzai_rebirth.client.renderer.SunderingAnchorRenderer;
import net.lust1212.lingzai_rebirth.registry.ModEntities;
import net.lust1212.lingzai_rebirth.registry.ModParticles;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import team.lodestar.lodestone.systems.particle.world.type.LodestoneWorldParticleType;

@Mod.EventBusSubscriber(modid = SpiritCalamityRebirth.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientSetup {

    @SubscribeEvent
    public static void registerParticleFactory(RegisterParticleProvidersEvent event) {
        Minecraft.getInstance().particleEngine.register(ModParticles.ROUNDABOUT_SLASH.get(), LodestoneWorldParticleType.Factory::new);
        Minecraft.getInstance().particleEngine.register(ModParticles.THIN_ROUNDABOUT_SLASH.get(), LodestoneWorldParticleType.Factory::new);
        Minecraft.getInstance().particleEngine.register(ModParticles.THIN_SLASH.get(), LodestoneWorldParticleType.Factory::new);
        Minecraft.getInstance().particleEngine.register(ModParticles.CHAOS_TARGET.get(), LodestoneWorldParticleType.Factory::new);
        Minecraft.getInstance().particleEngine.register(ModParticles.GIANT_ARROW.get(), LodestoneWorldParticleType.Factory::new);
    }

    @SubscribeEvent
    public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.SUNDERING_ANCHOR_PROJECTILE.get(), SunderingAnchorRenderer::new);
        event.registerEntityRenderer(ModEntities.ENTROPIC_FLAME_BOLT.get(), EntropicFlameBoltRenderer::new);
        event.registerEntityRenderer(ModEntities.FLYING_SWORD.get(), FlyingSwordRenderer::new);
    }
}