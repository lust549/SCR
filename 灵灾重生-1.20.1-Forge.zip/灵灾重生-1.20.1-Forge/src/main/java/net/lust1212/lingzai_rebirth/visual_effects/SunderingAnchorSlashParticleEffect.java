package net.lust1212.lingzai_rebirth.visual_effects;

import com.sammy.malum.client.PointyDirectionalBehaviorComponent;
import com.sammy.malum.core.systems.spirit.MalumSpiritType;
import com.sammy.malum.registry.common.SpiritTypeRegistry;
import com.sammy.malum.visual_effects.networked.ParticleEffectType;
import com.sammy.malum.visual_effects.networked.data.NBTEffectData;
import net.lust1212.lingzai_rebirth.registry.ModParticles;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import team.lodestar.lodestone.helpers.RandomHelper;
import team.lodestar.lodestone.systems.particle.data.GenericParticleData;
import team.lodestar.lodestone.systems.particle.data.spin.SpinParticleData;

import java.util.function.Supplier;

public class SunderingAnchorSlashParticleEffect extends ParticleEffectType {

    public SunderingAnchorSlashParticleEffect(String id) {
        super(id);
    }

    public static NBTEffectData createData(Vec3 direction, boolean mirror, float angle, int slashCount) {
        CompoundTag tag = new CompoundTag();
        CompoundTag directionTag = new CompoundTag();
        directionTag.putDouble("x", direction.x);
        directionTag.putDouble("y", direction.y);
        directionTag.putDouble("z", direction.z);
        tag.putFloat("angle", angle);
        tag.putBoolean("mirror", mirror);
        tag.putInt("slashCount", slashCount);
        tag.putString("spiritType", "*");
        tag.put("direction", directionTag);
        return new NBTEffectData(tag);
    }

    @OnlyIn(Dist.CLIENT)
    @Override
    public Supplier<ParticleEffectActor> get() {
        return () -> (level, random, positionData, colorData, nbtData) -> {
            CompoundTag tag = nbtData.compoundTag;
            if (!tag.contains("direction")) {
                return;
            }
            CompoundTag directionData = tag.getCompound("direction");
            Vec3 direction = new Vec3(directionData.getDouble("x"), directionData.getDouble("y"), directionData.getDouble("z"));
            float angle = tag.getFloat("angle");
            boolean mirror = tag.getBoolean("mirror");
            int slashCount = Math.max(1, tag.getInt("slashCount"));
            MalumSpiritType spirit = getSpiritType(tag);

            for (int i = 0; i < slashCount; i++) {
                float spinOffset = angle + RandomHelper.randomBetween(random, -3.14f, 3.14f) + (mirror ? 3.14f : 0);
                for (int j = 0; j < 2; j++) {
                    var slash = RebirthWeaponParticleEffects.spawnSlashParticle(level, positionData.getAsVector(), spirit, ModParticles.THIN_SLASH);
                    slash.getBuilder()
                            .setSpinData(SpinParticleData.create(0).setSpinOffset(spinOffset).build())
                            .setScaleData(GenericParticleData.create(RandomHelper.randomBetween(random, 1f, 2f)).build())
                            .setMotion(direction.scale(RandomHelper.randomBetween(random, 0.8f, 1.3f)))
                            .setLifeDelay((i + j) * 2)
                            .setLifetime(4)
                            .setBehavior(new PointyDirectionalBehaviorComponent(direction));
                    slash.spawnParticles();
                }
            }
        };
    }

    public static MalumSpiritType getSpiritType(CompoundTag tag) {
        MalumSpiritType spirit = SpiritTypeRegistry.SPIRITS.get(tag.getString("spiritType"));
        return spirit != null ? spirit : SpiritTypeRegistry.INFERNAL_SPIRIT;
    }
}