package net.lust1212.lingzai_rebirth.common.item;

import com.google.common.collect.ImmutableMultimap;
import com.sammy.malum.common.item.ISpiritAffiliatedItem;
import com.sammy.malum.common.item.curiosities.TemporarilyDisabledItem;
import com.sammy.malum.common.item.curiosities.weapons.scythe.MalumScytheItem;
import com.sammy.malum.core.systems.spirit.MalumSpiritType;
import com.sammy.malum.registry.common.AttributeRegistry;
import com.sammy.malum.registry.common.SpiritTypeRegistry;
import net.lust1212.lingzai_rebirth.common.entity.SunderingAnchorProjectile;
import net.lust1212.lingzai_rebirth.common.spirit.SpiritStorage;
import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.lust1212.lingzai_rebirth.registry.ModSounds;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import team.lodestar.lodestone.helpers.RandomHelper;
import team.lodestar.lodestone.helpers.SoundHelper;
import team.lodestar.lodestone.registry.common.LodestoneAttributeRegistry;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class SunderingAnchorItem extends MalumScytheItem implements ISpiritAffiliatedItem {
    public static final List<MalumSpiritType> SPIRITS = List.of(
            SpiritTypeRegistry.INFERNAL_SPIRIT, SpiritTypeRegistry.SACRED_SPIRIT,
            SpiritTypeRegistry.AQUEOUS_SPIRIT, SpiritTypeRegistry.EARTHEN_SPIRIT);

    private final float magicDamage;

    public SunderingAnchorItem(Tier tier, float magicDamage, Properties properties) {
        super(tier, -5f - tier.getAttackDamageBonus(), 1.2f, properties);
        this.magicDamage = magicDamage;
    }

    public static MalumSpiritType getSunderingAnchorSpirit() {
        return SPIRITS.get(ThreadLocalRandom.current().nextInt(SPIRITS.size()));
    }

    public static float getScytheProficiency(LivingEntity entity) {
        var instance = entity.getAttribute(AttributeRegistry.SCYTHE_PROFICIENCY.get());
        return instance == null ? 1f : (float) instance.getValue();
    }

    @Override
    public void hurtEvent(LivingHurtEvent event, LivingEntity attacker, LivingEntity target, ItemStack stack) {
    }

    @Override
    public ImmutableMultimap.Builder<Attribute, AttributeModifier> createExtraAttributes() {
        ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = new ImmutableMultimap.Builder<>();
        builder.put(LodestoneAttributeRegistry.MAGIC_DAMAGE.get(), new AttributeModifier(
                LodestoneAttributeRegistry.UUIDS.get(LodestoneAttributeRegistry.MAGIC_DAMAGE),
                "Weapon magic damage", magicDamage, AttributeModifier.Operation.ADDITION));
        return builder;
    }

    @Override
    public MalumSpiritType getDefiningSpiritType() {
        return getSunderingAnchorSpirit();
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.pass(stack);
        }
        if (player instanceof ServerPlayer serverPlayer) {
            if (stack.getEnchantmentLevel(net.lust1212.lingzai_rebirth.registry.ModEnchantments.WANJIAN_GUIZONG.get()) > 0) {
                int swordCount = serverPlayer.level().getEntitiesOfClass(net.lust1212.lingzai_rebirth.common.entity.FlyingSwordEntity.class,
                        serverPlayer.getBoundingBox().inflate(64), sword -> serverPlayer.equals(sword.getOwner())).size();
                if (swordCount < net.lust1212.lingzai_rebirth.common.entity.FlyingSwordEntity.MAX_SWORDS) {
                    ItemStack swordStack = stack.copy();
                    stack.shrink(1);
                    net.lust1212.lingzai_rebirth.common.entity.FlyingSwordEntity.summon(serverPlayer, swordStack);
                    SoundHelper.playSound(player, com.sammy.malum.registry.common.SoundRegistry.SCYTHE_THROW.get(), 0.5f, 1.5f);
                }
                return InteractionResultHolder.success(stack);
            }
            int slot = hand == InteractionHand.OFF_HAND ? player.getInventory().getContainerSize() - 1 : player.getInventory().selected;
            float physicalDamage = (float) player.getAttributeValue(Attributes.ATTACK_DAMAGE);
            float magic = (float) player.getAttributeValue(LodestoneAttributeRegistry.MAGIC_DAMAGE.get());
            SpiritStorage storage = SpiritStorage.read(stack);
            Vec3 pos = getProjectileSpawnPos(player, hand, 0.5f, 0.5f);
            SunderingAnchorProjectile projectile = new SunderingAnchorProjectile(level, pos.x, pos.y, pos.z);
            projectile.setData(player, physicalDamage, magic, slot);
            projectile.setSplits(stack.getEnchantmentLevel(net.lust1212.lingzai_rebirth.registry.ModEnchantments.FISSION.get()));
            projectile.setSpecialEnchants(
                    stack.getEnchantmentLevel(net.lust1212.lingzai_rebirth.registry.ModEnchantments.PIERCING.get()),
                    stack.getEnchantmentLevel(net.lust1212.lingzai_rebirth.registry.ModEnchantments.GATHER.get()));
            projectile.setViolence(stack.getEnchantmentLevel(net.lust1212.lingzai_rebirth.registry.ModEnchantments.VIOLENCE.get()));
            projectile.setKineticAcceleration(stack.getEnchantmentLevel(net.lust1212.lingzai_rebirth.registry.ModEnchantments.KINETIC_ACCELERATION.get()));
            projectile.setSpiritStorage(storage);
            projectile.setItem(stack);
            projectile.shootFromRotation(player, player.getXRot(), player.getYRot(), 0, 2.5f * (1f + storage.bonus(SpiritTypeRegistry.AERIAL_SPIRIT)), 0f);
            level.addFreshEntity(projectile);
            SoundHelper.playSound(player, com.sammy.malum.registry.common.SoundRegistry.SCYTHE_THROW.get(), 0.5f, RandomHelper.randomBetween(level.random, 1.5f, 2f));
            TemporarilyDisabledItem.disable(serverPlayer, slot, ModItems.SOUL_OF_THE_ANCHOR.get());
            applyCooldown(stack, player);
        }
        return InteractionResultHolder.success(stack);
    }

    public static void applyCooldown(ItemStack stack, Player player) {
        applyCooldown(stack, player, 1);
    }

    public static void applyCooldown(ItemStack stack, Player player, float scalar) {
        if (!player.isCreative()) {
            player.getCooldowns().addCooldown(stack.getItem(), (int) (200 * scalar));
        }
    }

    public static void applyHatred(LivingEntity target) {
        MobEffectInstance effect = target.getEffect(net.lust1212.lingzai_rebirth.registry.ModMobEffects.HATRED.get());
        int duration = effect == null ? 120 : Math.min(effect.getDuration() + 60, 3000);
        int amplifier = effect == null ? 0 : Math.min(effect.getAmplifier() + 1, 49);
        target.addEffect(new MobEffectInstance(net.lust1212.lingzai_rebirth.registry.ModMobEffects.HATRED.get(), duration, amplifier, true, true, true));
    }

    public Vec3 getProjectileSpawnPos(LivingEntity player, InteractionHand hand, float distance, float spread) {
        int angle = hand == InteractionHand.MAIN_HAND ? 225 : 90;
        double radians = Math.toRadians(angle - player.yHeadRot);
        return player.position().add(player.getLookAngle().scale(distance))
                .add(spread * Math.sin(radians), player.getBbHeight() * 0.9f, spread * Math.cos(radians));
    }

    public static int rollSlashCount(net.minecraft.util.RandomSource random) {
        return 3 + Mth.floor(random.nextFloat() * 3);
    }
}