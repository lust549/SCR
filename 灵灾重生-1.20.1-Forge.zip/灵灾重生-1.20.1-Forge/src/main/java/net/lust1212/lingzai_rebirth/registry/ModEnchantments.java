package net.lust1212.lingzai_rebirth.registry;

import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.lust1212.lingzai_rebirth.common.enchantment.FissionEnchantment;
import net.lust1212.lingzai_rebirth.common.enchantment.GatherEnchantment;
import net.lust1212.lingzai_rebirth.common.enchantment.KineticAccelerationEnchantment;
import net.lust1212.lingzai_rebirth.common.enchantment.OverlimitEnchantment;
import net.lust1212.lingzai_rebirth.common.enchantment.PiercingEnchantment;
import net.lust1212.lingzai_rebirth.common.enchantment.SpiritStorageEnchantment;
import net.lust1212.lingzai_rebirth.common.enchantment.SuperLimitBreakEnchantment;
import net.lust1212.lingzai_rebirth.common.enchantment.ViolenceEnchantment;
import net.lust1212.lingzai_rebirth.common.enchantment.WanjianGuizongEnchantment;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEnchantments {
    public static final DeferredRegister<Enchantment> ENCHANTMENTS = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, SpiritCalamityRebirth.MOD_ID);

    public static final RegistryObject<Enchantment> WANJIAN_GUIZONG = ENCHANTMENTS.register("wanjian_guizong", WanjianGuizongEnchantment::new);

    public static final RegistryObject<Enchantment> FISSION = ENCHANTMENTS.register("fission", FissionEnchantment::new);

    public static final RegistryObject<Enchantment> PIERCING = ENCHANTMENTS.register("piercing", PiercingEnchantment::new);

    public static final RegistryObject<Enchantment> GATHER = ENCHANTMENTS.register("gather", GatherEnchantment::new);

    public static final RegistryObject<Enchantment> VIOLENCE = ENCHANTMENTS.register("violence", ViolenceEnchantment::new);

    public static final RegistryObject<Enchantment> KINETIC_ACCELERATION = ENCHANTMENTS.register("kinetic_acceleration", KineticAccelerationEnchantment::new);

    public static final RegistryObject<Enchantment> SPIRIT_STORAGE = ENCHANTMENTS.register("spirit_storage", SpiritStorageEnchantment::new);

    public static final RegistryObject<Enchantment> OVERLIMIT = ENCHANTMENTS.register("overlimit", OverlimitEnchantment::new);

    public static final RegistryObject<Enchantment> SUPER_LIMIT_BREAK = ENCHANTMENTS.register("super_limit_break", SuperLimitBreakEnchantment::new);
}