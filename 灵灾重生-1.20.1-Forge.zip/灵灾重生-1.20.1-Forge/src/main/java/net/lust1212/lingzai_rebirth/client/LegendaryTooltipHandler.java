package net.lust1212.lingzai_rebirth.client;

import com.sammy.malum.core.systems.spirit.MalumSpiritType;
import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.lust1212.lingzai_rebirth.common.enchantment.LegendaryAnchorEnchantment;
import net.lust1212.lingzai_rebirth.common.enchantment.SuperLimitBreakEnchantment;
import net.lust1212.lingzai_rebirth.common.spirit.SpiritStorage;
import net.lust1212.lingzai_rebirth.registry.ModEnchantments;
import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;

@Mod.EventBusSubscriber(modid = SpiritCalamityRebirth.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class LegendaryTooltipHandler {

    @SubscribeEvent
    public static void onItemTooltip(ItemTooltipEvent event) {
        ItemStack stack = event.getItemStack();
        if (stack.isEmpty()) {
            return;
        }
        Map<Enchantment, Integer> enchantments = EnchantmentHelper.getEnchantments(stack);
        if (hasAncientEnchantment(enchantments)) {
            event.getToolTip().add(SuperLimitBreakEnchantment.rainbowGradient(
                    Component.translatable("tooltip.lingzai_rebirth.ancient").getString()));
        } else if (hasMythicEnchantment(enchantments)) {
            event.getToolTip().add(Component.translatable("tooltip.lingzai_rebirth.mythic").withStyle(ChatFormatting.RED));
        } else if (hasLegendaryEnchantment(enchantments)) {
            event.getToolTip().add(Component.translatable("tooltip.lingzai_rebirth.legendary").withStyle(ChatFormatting.GOLD));
        }
        if (stack.is(ModItems.SUNDERING_ANCHOR.get()) && enchantments.containsKey(ModEnchantments.SPIRIT_STORAGE.get())) {
            addStoredSpirits(event.getToolTip(), stack);
        }
    }

    private static boolean hasAncientEnchantment(Map<Enchantment, Integer> enchantments) {
        return enchantments.containsKey(ModEnchantments.SUPER_LIMIT_BREAK.get());
    }

    private static boolean hasMythicEnchantment(Map<Enchantment, Integer> enchantments) {
        return enchantments.containsKey(ModEnchantments.OVERLIMIT.get());
    }

    private static boolean hasLegendaryEnchantment(Map<Enchantment, Integer> enchantments) {
        for (Enchantment enchantment : enchantments.keySet()) {
            if (enchantment instanceof LegendaryAnchorEnchantment) {
                return true;
            }
        }
        return false;
    }

    private static void addStoredSpirits(java.util.List<Component> tooltip, ItemStack stack) {
        SpiritStorage storage = SpiritStorage.read(stack);
        if (storage.isEmpty()) {
            return;
        }
        MutableComponent line = Component.translatable("tooltip.lingzai_rebirth.stored_spirits");
        boolean first = true;
        for (MalumSpiritType type : SpiritStorage.TYPES) {
            int count = storage.get(type);
            if (count <= 0) {
                continue;
            }
            line.append(first ? " " : ", ");
            line.append(new ItemStack(type.spiritShard.get()).getHoverName());
            line.append(" x" + count);
            first = false;
        }
        tooltip.add(line);
    }
}