package net.lust1212.lingzai_rebirth.common.item;

import com.sammy.malum.common.capability.MalumPlayerDataCapability;
import com.sammy.malum.common.entity.nitrate.EthericNitrateEntity;
import com.sammy.malum.common.item.ISpiritAffiliatedItem;
import com.sammy.malum.common.item.curiosities.weapons.staff.AbstractStaffItem;
import com.sammy.malum.core.systems.spirit.MalumSpiritType;
import com.sammy.malum.registry.common.SpiritTypeRegistry;
import net.lust1212.lingzai_rebirth.common.entity.bolt.EntropicFlameBolt;
import net.lust1212.lingzai_rebirth.registry.ModParticles;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import team.lodestar.lodestone.handlers.RenderHandler;
import team.lodestar.lodestone.registry.common.LodestoneAttributeRegistry;
import team.lodestar.lodestone.systems.easing.Easing;
import team.lodestar.lodestone.systems.particle.builder.WorldParticleBuilder;
import team.lodestar.lodestone.systems.particle.data.GenericParticleData;
import team.lodestar.lodestone.systems.particle.data.color.ColorParticleData;
import team.lodestar.lodestone.systems.particle.data.spin.SpinParticleData;
import team.lodestar.lodestone.systems.particle.render_types.LodestoneWorldParticleRenderType;
import team.lodestar.lodestone.systems.particle.world.behaviors.components.DirectionalBehaviorComponent;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class UnwindingChaosStaffItem extends AbstractStaffItem implements ISpiritAffiliatedItem {
    public static final List<MalumSpiritType> SPIRITS = List.of(
            SpiritTypeRegistry.INFERNAL_SPIRIT, SpiritTypeRegistry.SACRED_SPIRIT,
            SpiritTypeRegistry.AQUEOUS_SPIRIT, SpiritTypeRegistry.EARTHEN_SPIRIT);

    public static final ColorParticleData AURIC_COLOR_DATA = EthericNitrateEntity.AURIC_COLOR_DATA;

    public UnwindingChaosStaffItem(Tier tier, float magicDamage, int chargeDuration, Properties properties) {
        super(tier, -0.2f, chargeDuration, magicDamage, properties);
    }

    public static MalumSpiritType getUnwindingChaosSpirit() {
        return SPIRITS.get(ThreadLocalRandom.current().nextInt(SPIRITS.size()));
    }

    @Override
    public MalumSpiritType getDefiningSpiritType() {
        return getUnwindingChaosSpirit();
    }

    @Override
    public int getCooldownDuration(Level level, LivingEntity livingEntity) {
        return 160;
    }

    @Override
    public int getProjectileCount(Level level, LivingEntity livingEntity, float pct) {
        if (pct == 1f && livingEntity instanceof Player player) {
            var capability = MalumPlayerDataCapability.getCapability(player);
            int charges = Math.max(0, capability.reserveStaffChargeHandler.chargeCount);
            capability.reserveStaffChargeHandler.chargeCount = 0;
            return 3 + charges * 2;
        }
        return 0;
    }

    @Override
    public void fireProjectile(LivingEntity player, ItemStack stack, Level level, InteractionHand hand, float chargePercentage, int count) {
        int ceil = Mth.ceil(count / 2f);
        int spawnDelay = 1 + ceil * 2;
        ceil = ceil % 7;
        float spread = count > 0 ? ceil * 0.1f * (count % 2L == 0 ? 1 : -1) : 0f;
        float pitchOffset = count > 4 ? 2f + (2f - ceil * 1.5f) : 0.5f;
        float velocity = 3f;
        float magicDamage = (float) player.getAttributeValue(LodestoneAttributeRegistry.MAGIC_DAMAGE.get());
        Vec3 pos = getProjectileSpawnPos(player, hand, 0.5f, 0.5f);
        EntropicFlameBolt projectile = new EntropicFlameBolt(level, pos.x, pos.y, pos.z);
        projectile.setData(player, magicDamage, spawnDelay);
        projectile.setItem(stack);
        projectile.shootFromRotation(player, player.getXRot(), player.getYRot(), -pitchOffset, velocity, 0f);
        var direction = projectile.getDeltaMovement();
        float yRot = ((float) (Mth.atan2(direction.x, direction.z) * (double) (180F / (float) Math.PI)));
        float yaw = (float) Math.toRadians(yRot);
        var left = new Vec3(-Math.cos(yaw), 0, Math.sin(yaw));
        projectile.setDeltaMovement(projectile.getDeltaMovement().add(left.scale(spread)));
        level.addFreshEntity(projectile);
    }

    @OnlyIn(Dist.CLIENT)
    @Override
    public void spawnChargeParticles(Level level, LivingEntity livingEntity, Vec3 pos, ItemStack stack, float pct) {
        Vec3 look = livingEntity.getLookAngle().normalize();
        var builder = WorldParticleBuilder.create(ModParticles.CHAOS_TARGET, new DirectionalBehaviorComponent(look))
                .setTransparencyData(GenericParticleData.create(0.7f * pct, 0f).setEasing(Easing.SINE_IN_OUT, Easing.SINE_IN).build())
                .setScaleData(GenericParticleData.create(0.3f * pct, 0).setEasing(Easing.SINE_IN_OUT).build())
                .setMotion(look.scale(0.2f * pct))
                .setRenderTarget(RenderHandler.LATE_DELAYED_RENDER)
                .enableForcedSpawn()
                .setLifetime(4)
                .enableNoClip();
        for (int i = 0; i < 2; i++) {
            var spin = SpinParticleData.create(0.05f, 0.1f);
            long delta = (i == 1 ? 1 : -1) * (level.getGameTime() + i * 5);
            float offset = 0.4f * Mth.sin((delta / 8f) % 6.28f);
            MalumSpiritType spirit = i == 0 ? SpiritTypeRegistry.AQUEOUS_SPIRIT : SpiritTypeRegistry.INFERNAL_SPIRIT;
            builder.setColorData(spirit.createColorData().build())
                    .setLifeDelay(i == 0 ? 2 : 4)
                    .setSpinData(spin.setSpinOffset(i * 1.57f + offset).build())
                    .setRenderType(LodestoneWorldParticleRenderType.ADDITIVE)
                    .spawn(level, pos.x, pos.y, pos.z)
                    .setRenderType(LodestoneWorldParticleRenderType.LUMITRANSPARENT)
                    .spawn(level, pos.x, pos.y, pos.z);
        }
    }
}