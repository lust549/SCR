package net.lust1212.lingzai_rebirth.common.handler;

import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.lust1212.lingzai_rebirth.common.entity.FlyingSwordEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = SpiritCalamityRebirth.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class SwordReturnHandler {
    private static final Map<UUID, List<ItemStack>> PENDING_RETURNS = new HashMap<>();

    public static void storePendingReturn(UUID playerId, ItemStack stack) {
        if (!stack.isEmpty()) {
            PENDING_RETURNS.computeIfAbsent(playerId, id -> new ArrayList<>()).add(stack);
        }
    }

    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        List<ItemStack> stacks = PENDING_RETURNS.remove(player.getUUID());
        if (stacks == null) {
            return;
        }
        for (ItemStack stack : stacks) {
            if (!stack.isEmpty()) {
                FlyingSwordEntity.giveBack(player, stack);
            }
        }
    }
}