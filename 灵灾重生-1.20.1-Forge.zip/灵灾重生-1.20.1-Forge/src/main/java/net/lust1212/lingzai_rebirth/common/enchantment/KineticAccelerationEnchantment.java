package net.lust1212.lingzai_rebirth.common.enchantment;

public class KineticAccelerationEnchantment extends LegendaryAnchorEnchantment {
}