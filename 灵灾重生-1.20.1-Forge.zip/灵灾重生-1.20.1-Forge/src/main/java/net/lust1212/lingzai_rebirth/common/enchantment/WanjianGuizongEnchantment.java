package net.lust1212.lingzai_rebirth.common.enchantment;

import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;

public class WanjianGuizongEnchantment extends Enchantment {

    public WanjianGuizongEnchantment() {
        super(Rarity.RARE, EnchantmentCategory.WEAPON, new EquipmentSlot[]{EquipmentSlot.MAINHAND});
    }

    @Override
    public int getMaxLevel() {
        return 1;
    }

    @Override
    public boolean canEnchant(ItemStack stack) {
        return stack.is(ModItems.SUNDERING_ANCHOR.get());
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack) {
        return stack.is(ModItems.SUNDERING_ANCHOR.get());
    }
}