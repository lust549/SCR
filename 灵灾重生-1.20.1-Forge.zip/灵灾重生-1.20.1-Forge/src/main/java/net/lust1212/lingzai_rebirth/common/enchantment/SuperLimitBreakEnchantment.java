package net.lust1212.lingzai_rebirth.common.enchantment;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.TextColor;
import net.minecraft.util.Mth;

public class SuperLimitBreakEnchantment extends LegendaryAnchorEnchantment {

    @Override
    public Component getFullname(int level) {
        return rainbowGradient(Component.translatable(getDescriptionId()).getString());
    }

    public static MutableComponent rainbowGradient(String text) {
        MutableComponent result = Component.empty();
        int length = Math.max(1, text.length());
        for (int i = 0; i < text.length(); i++) {
            float hue = (float) i / length;
            float brightness = i % 2 == 0 ? 1f : 0.85f;
            int rgb = Mth.hsvToRgb(hue, 1f, brightness);
            result.append(Component.literal(String.valueOf(text.charAt(i)))
                    .withStyle(style -> style.withColor(TextColor.fromRgb(rgb)).withBold(true)));
        }
        return result;
    }
}