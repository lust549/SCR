package net.lust1212.lingzai_rebirth.common.handler;

import com.sammy.malum.visual_effects.networked.data.ColorEffectData;
import com.sammy.malum.visual_effects.networked.data.PositionEffectData;
import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.lust1212.lingzai_rebirth.common.item.SunderingAnchorItem;
import net.lust1212.lingzai_rebirth.registry.ModDamageTypes;
import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.lust1212.lingzai_rebirth.registry.ModParticleEffectTypes;
import net.lust1212.lingzai_rebirth.registry.ModSounds;
import net.lust1212.lingzai_rebirth.visual_effects.SunderingAnchorSlashParticleEffect;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.resources.ResourceKey;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import team.lodestar.lodestone.helpers.SoundHelper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Mod.EventBusSubscriber(modid = SpiritCalamityRebirth.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class AnchorComboHandler {
    private static final List<PendingStrike> PENDING_STRIKES = new ArrayList<>();

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onLivingHurt(LivingHurtEvent event) {
        if (!(event.getEntity().level() instanceof ServerLevel level)) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)) {
            return;
        }
        if (!(attacker instanceof Player player)) {
            return;
        }
        ItemStack stack = player.getMainHandItem();
        if (!stack.is(ModItems.SUNDERING_ANCHOR.get())) {
            return;
        }
        if (event.getSource().is(ModDamageTypes.SUNDERING_ANCHOR_COMBO)
                || event.getSource().is(ModDamageTypes.SUNDERING_ANCHOR_MAGIC_COMBO)
                || UnstoppableDamageHandler.isThrowDamage(event.getSource())) {
            return;
        }
        if (!event.getSource().getDirectEntity().equals(player)) {
            return;
        }
        LivingEntity target = event.getEntity();
        var random = level.random;
        int slashCount = SunderingAnchorItem.rollSlashCount(random);
        float splitDamage = event.getAmount() / slashCount;
        float magic = (float) player.getAttributeValue(team.lodestar.lodestone.registry.common.LodestoneAttributeRegistry.MAGIC_DAMAGE.get());
        float splitMagic = Math.max(magic, 0) / slashCount;
        boolean overlimit = UnstoppableDamageHandler.hasOverlimit(stack);
        ResourceKey<DamageType> damageType = overlimit ? ModDamageTypes.OVERLIMIT_STRIKE : ModDamageTypes.SUNDERING_ANCHOR_COMBO;
        ResourceKey<DamageType> magicType = overlimit ? ModDamageTypes.OVERLIMIT_MAGIC_STRIKE : ModDamageTypes.SUNDERING_ANCHOR_MAGIC_COMBO;

        if (target.isAlive()) {
            for (int i = 0; i < slashCount; i++) {
                PENDING_STRIKES.add(new PendingStrike(level, player, target, splitDamage, splitMagic, 8 + i,
                        ModSounds.SUNDERING_ANCHOR_EXTRA_SWING.get(), 1.2f, 0.7f,
                        damageType, magicType, stack, true));
            }
            SunderingAnchorItem.applyHatred(target);
            ModParticleEffectTypes.SUNDERING_ANCHOR_SLASH.createEntityEffect(attacker,
                    new ColorEffectData(SunderingAnchorItem.getSunderingAnchorSpirit()),
                    SunderingAnchorSlashParticleEffect.createData(attacker.getLookAngle(), random.nextBoolean(), random.nextFloat() * 6.28f, slashCount));
        }
        if (UnstoppableDamageHandler.hasSuperLimitBreak(stack)) {
            PENDING_STRIKES.add(new PendingStrike(level, player, target, splitDamage, splitMagic, 1,
                    ModSounds.SUNDERING_ANCHOR_EXTRA_SWING.get(), 0f, 0.7f,
                    damageType, magicType, stack, true));
            UnstoppableDamageHandler.overrideAmount(event, 0f);
            event.setAmount(0f);
        } else if (overlimit) {
            UnstoppableDamageHandler.forcePierceNoDeath(target, splitDamage);
            UnstoppableDamageHandler.overrideAmount(event, 0f);
            event.setAmount(0f);
        } else {
            event.setAmount(splitDamage);
        }
        SoundHelper.playSound(attacker, ModSounds.SUNDERING_ANCHOR_SWING.get(), 1f, team.lodestar.lodestone.helpers.RandomHelper.randomBetween(random, 0.8f, 1.2f));
    }

    public static void scheduleProjectileCombo(ServerLevel level, LivingEntity attacker, LivingEntity target, float damage, float magicDamage, int slashCount, int baseDelay,
                                               ResourceKey<DamageType> damageType, ResourceKey<DamageType> magicType, ItemStack anchor, boolean showEffect) {
        for (int i = 0; i < slashCount; i++) {
            PENDING_STRIKES.add(new PendingStrike(level, attacker, target, damage, magicDamage, baseDelay + i,
                    ModSounds.SUNDERING_ANCHOR_PROJECTILE_SWING.get(), 1.25f, 0.7f,
                    damageType, magicType, anchor, showEffect));
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || PENDING_STRIKES.isEmpty()) {
            return;
        }
        List<PendingStrike> due = new ArrayList<>();
        Iterator<PendingStrike> iterator = PENDING_STRIKES.iterator();
        while (iterator.hasNext()) {
            PendingStrike strike = iterator.next();
            strike.delay--;
            if (strike.delay > 0) {
                continue;
            }
            iterator.remove();
            due.add(strike);
        }
        for (PendingStrike strike : due) {
            strike.execute();
        }
    }

    private static class PendingStrike {
        private final ServerLevel level;
        private final LivingEntity attacker;
        private final LivingEntity target;
        private final float damage;
        private final float magicDamage;
        private final net.minecraft.sounds.SoundEvent sound;
        private final float volume;
        private final float pitch;
        private final ResourceKey<DamageType> damageType;
        private final ResourceKey<DamageType> magicType;
        private final ItemStack anchor;
        private final boolean showEffect;
        private int delay;

        private PendingStrike(ServerLevel level, LivingEntity attacker, LivingEntity target, float damage, float magicDamage, int delay,
                              net.minecraft.sounds.SoundEvent sound, float volume, float pitch,
                              ResourceKey<DamageType> damageType, ResourceKey<DamageType> magicType, ItemStack anchor, boolean showEffect) {
            this.level = level;
            this.attacker = attacker;
            this.target = target;
            this.damage = damage;
            this.magicDamage = magicDamage;
            this.delay = delay;
            this.sound = sound;
            this.volume = volume;
            this.pitch = pitch;
            this.damageType = damageType;
            this.magicType = magicType;
            this.anchor = anchor;
            this.showEffect = showEffect;
        }

        private void execute() {
            if (!target.isAlive() || target.level() != level || !attacker.isAlive()) {
                return;
            }
            UnstoppableDamageHandler.forcePierce(target, UnstoppableDamageHandler.createStrikeSource(level, anchor, damageType, attacker, attacker), UnstoppableDamageHandler.breakAmount(anchor, damage));
            if (magicDamage > 0 && target.isAlive()) {
                target.invulnerableTime = 0;
                UnstoppableDamageHandler.forcePierce(target, UnstoppableDamageHandler.createStrikeSource(level, anchor, magicType, attacker, attacker), UnstoppableDamageHandler.breakAmount(anchor, magicDamage));
            }
            SoundHelper.playSound(target, sound, volume, pitch);
            if (showEffect) {
                Vec3 position = target.position().add(0, target.getBbHeight() * 0.5f, 0);
                ModParticleEffectTypes.SUNDERING_ANCHOR_SWEEP.createPositionedEffect(level,
                        new PositionEffectData(position),
                        new ColorEffectData(SunderingAnchorItem.getSunderingAnchorSpirit()), null);
            }
        }
    }
}