package net.lust1212.lingzai_rebirth.common.enchantment;

import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;

public abstract class LegendaryAnchorEnchantment extends Enchantment {

    protected LegendaryAnchorEnchantment() {
        super(Rarity.VERY_RARE, EnchantmentCategory.WEAPON, new EquipmentSlot[]{EquipmentSlot.MAINHAND});
    }

    @Override
    public int getMaxLevel() {
        return 1;
    }

    @Override
    public boolean canEnchant(ItemStack stack) {
        return stack.is(ModItems.SUNDERING_ANCHOR.get());
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack) {
        return stack.is(ModItems.SUNDERING_ANCHOR.get());
    }

    @Override
    public Component getFullname(int level) {
        return Component.translatable(getDescriptionId()).withStyle(ChatFormatting.GOLD);
    }
}