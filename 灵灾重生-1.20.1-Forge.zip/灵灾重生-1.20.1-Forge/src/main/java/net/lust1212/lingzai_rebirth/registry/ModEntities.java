package net.lust1212.lingzai_rebirth.registry;

import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.lust1212.lingzai_rebirth.common.entity.SunderingAnchorProjectile;
import net.lust1212.lingzai_rebirth.common.entity.bolt.EntropicFlameBolt;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SpiritCalamityRebirth.MOD_ID);

    public static final RegistryObject<EntityType<SunderingAnchorProjectile>> SUNDERING_ANCHOR_PROJECTILE = ENTITIES.register("sundering_anchor_projectile",
            () -> EntityType.Builder.<SunderingAnchorProjectile>of((type, level) -> new SunderingAnchorProjectile(type, level), MobCategory.MISC)
                    .sized(1.5f, 1.5f)
                    .clientTrackingRange(20)
                    .updateInterval(1)
                    .build(new ResourceLocation(SpiritCalamityRebirth.MOD_ID, "sundering_anchor_projectile").toString()));

    public static final RegistryObject<EntityType<EntropicFlameBolt>> ENTROPIC_FLAME_BOLT = ENTITIES.register("entropic_flame_bolt",
            () -> EntityType.Builder.<EntropicFlameBolt>of((type, level) -> new EntropicFlameBolt(type, level), MobCategory.MISC)
                    .sized(1.5f, 1.5f)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build(new ResourceLocation(SpiritCalamityRebirth.MOD_ID, "entropic_flame_bolt").toString()));

    public static final RegistryObject<EntityType<net.lust1212.lingzai_rebirth.common.entity.FlyingSwordEntity>> FLYING_SWORD = ENTITIES.register("flying_sword",
            () -> EntityType.Builder.<net.lust1212.lingzai_rebirth.common.entity.FlyingSwordEntity>of((type, level) -> new net.lust1212.lingzai_rebirth.common.entity.FlyingSwordEntity(type, level), MobCategory.MISC)
                    .sized(1.2f, 1.2f)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build(new ResourceLocation(SpiritCalamityRebirth.MOD_ID, "flying_sword").toString()));
}