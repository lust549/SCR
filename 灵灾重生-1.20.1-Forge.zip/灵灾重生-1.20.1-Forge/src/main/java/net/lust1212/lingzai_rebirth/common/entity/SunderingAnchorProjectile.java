package net.lust1212.lingzai_rebirth.common.entity;

import com.sammy.malum.client.PointyDirectionalBehaviorComponent;
import com.sammy.malum.common.item.curiosities.TemporarilyDisabledItem;
import com.sammy.malum.core.systems.spirit.MalumSpiritType;
import com.sammy.malum.registry.common.SpiritTypeRegistry;
import com.sammy.malum.visual_effects.SpiritLightSpecs;
import com.sammy.malum.visual_effects.networked.data.ColorEffectData;
import com.sammy.malum.visual_effects.networked.data.PositionEffectData;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.lust1212.lingzai_rebirth.common.handler.AnchorComboHandler;
import net.lust1212.lingzai_rebirth.common.handler.SpiritStorageHandler;
import net.lust1212.lingzai_rebirth.common.handler.UnstoppableDamageHandler;
import net.lust1212.lingzai_rebirth.common.item.SunderingAnchorItem;
import net.lust1212.lingzai_rebirth.common.spirit.SpiritStorage;
import net.lust1212.lingzai_rebirth.registry.ModDamageTypes;
import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.lust1212.lingzai_rebirth.registry.ModMobEffects;
import net.lust1212.lingzai_rebirth.registry.ModParticleEffectTypes;
import net.lust1212.lingzai_rebirth.registry.ModParticles;
import net.lust1212.lingzai_rebirth.registry.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.entity.PartEntity;
import team.lodestar.lodestone.handlers.RenderHandler;
import team.lodestar.lodestone.helpers.ColorHelper;
import team.lodestar.lodestone.helpers.RandomHelper;
import team.lodestar.lodestone.helpers.SoundHelper;
import team.lodestar.lodestone.systems.easing.Easing;
import team.lodestar.lodestone.systems.particle.SimpleParticleOptions;
import team.lodestar.lodestone.systems.particle.builder.WorldParticleBuilder;
import team.lodestar.lodestone.systems.particle.data.GenericParticleData;
import team.lodestar.lodestone.systems.particle.data.color.ColorParticleData;
import team.lodestar.lodestone.systems.particle.data.spin.SpinParticleData;
import team.lodestar.lodestone.systems.particle.render_types.LodestoneWorldParticleRenderType;
import team.lodestar.lodestone.systems.rendering.trail.TrailPointBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class SunderingAnchorProjectile extends ThrowableItemProjectile {

    public static final float HEADSHOT_THRESHOLD = 0.7f;
    public static final float LOCK_ON_AIM_HEIGHT = 0.85f;
    public static final float HEADSHOT_DAMAGE_MULTIPLIER = 2f;
    public static final int CLONE_LIFETIME = 100;
    public static final int PIERCE_HITS = 5;
    private static final double PIERCE_SPEED = 2.2;
    private static final double PIERCE_PASS_RANGE = 12.0;
    private static final double PIERCE_CORRIDOR = 1.6;
    private static final double PIERCE_SCAN_RADIUS = 20.0;
    private static final double PIERCE_HOMING = 0.12;
    private static final int PIERCE_MAX_TICKS = 100;
    private static final double GATHER_RADIUS = 8.0;
    private static final double GATHER_RING_RADIUS = 1.5;
    private static final int VIOLENCE_TICKS_PER_LEVEL = 1200;
    private static final float KINETIC_SPEED_PER_BOUNCE = 0.06f;
    private static final float KINETIC_DAMAGE_PER_BOUNCE = 0.08f;
    private static final float KINETIC_MAX_DAMAGE_BONUS = 1.0f;
    private static final float EARTHEN_BOUNCE_SPEED_SCALE = 0.5f;
    private static final double AQUEOUS_BASE_SPEED = 2.5;
    private static final double AQUEOUS_ACCELERATION = 0.05;
    private static final int MAX_STOLEN_EFFECTS = 12;

    public TrailPointBuilder trailPointBuilder = TrailPointBuilder.create(60);
    public TrailPointBuilder spinningTrailPointBuilder = TrailPointBuilder.create(8);
    public float spinOffset = (float) (random.nextFloat() * Math.PI * 2);
    protected float damage;
    protected float magicDamage;
    public int age;

    public int reboundDelay;
    public int bounceCount;

    public boolean isReturning;
    public int returnTimer;

    public int slot;

    public int splitsRemaining;
    private static final net.minecraft.network.syncher.EntityDataAccessor<Boolean> DATA_CLONE =
            net.minecraft.network.syncher.SynchedEntityData.defineId(SunderingAnchorProjectile.class, net.minecraft.network.syncher.EntityDataSerializers.BOOLEAN);

    public boolean isClone() {
        return getEntityData().get(DATA_CLONE);
    }

    public void setClone(boolean clone) {
        getEntityData().set(DATA_CLONE, clone);
    }

    public int cloneLifetime;

    public int pierceLevel;
    public int gatherLevel;
    private boolean piercing;
    private Vec3 pierceDirection = Vec3.ZERO;
    private int pierceHitsRemaining;
    private double pierceTravel;
    private int pierceAge;
    private LivingEntity pierceTarget;
    private final List<Entity> piercedThisPass = new ArrayList<>();
    private boolean gatherTriggered;

    public int violenceLevel;
    private int violenceAge;

    public int kineticLevel;
    public float bounceDamageBonus;
    private SpiritStorage spiritStorage = new SpiritStorage();
    private final List<MobEffectInstance> stolenEffects = new ArrayList<>();

    private final List<Entity> ignoredTargets = new ArrayList<>();
    private final Object2IntOpenHashMap<Entity> hitCount = new Object2IntOpenHashMap<>();
    private LivingEntity forcedTarget;

    public SunderingAnchorProjectile(net.minecraft.world.entity.EntityType<? extends ThrowableItemProjectile> entityType, Level level) {
        super(entityType, level);
        noPhysics = false;
    }

    public SunderingAnchorProjectile(Level level, double x, double y, double z) {
        this(net.lust1212.lingzai_rebirth.registry.ModEntities.SUNDERING_ANCHOR_PROJECTILE.get(), level);
        setPos(x, y, z);
        noPhysics = false;
    }

    public void setData(LivingEntity owner, float damage, float magicDamage, int slot) {
        setOwner(owner);
        this.damage = damage;
        this.magicDamage = magicDamage;
        this.slot = slot;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        getEntityData().define(DATA_CLONE, false);
    }

    public void setSplits(int splits) {
        this.splitsRemaining = splits;
    }

    public void setSpecialEnchants(int pierceLevel, int gatherLevel) {
        this.pierceLevel = pierceLevel;
        this.gatherLevel = gatherLevel;
    }

    public void setViolence(int level) {
        this.violenceLevel = level;
    }

    public void setKineticAcceleration(int level) {
        this.kineticLevel = level;
    }

    public void setSpiritStorage(SpiritStorage storage) {
        this.spiritStorage = storage;
    }

    public boolean isOverlimit() {
        return UnstoppableDamageHandler.hasOverlimit(getItem());
    }

    private ResourceKey<DamageType> strikeType() {
        return isOverlimit() ? ModDamageTypes.OVERLIMIT_STRIKE : ModDamageTypes.ANCHOR_THROW_STRIKE;
    }

    private ResourceKey<DamageType> magicStrikeType() {
        return isOverlimit() ? ModDamageTypes.OVERLIMIT_MAGIC_STRIKE : ModDamageTypes.ANCHOR_THROW_MAGIC_STRIKE;
    }

    private DamageSource strikeSource(ServerLevel level, LivingEntity owner) {
        return UnstoppableDamageHandler.createStrikeSource(level, getItem(), strikeType(), this, owner);
    }

    private DamageSource magicStrikeSource(ServerLevel level, LivingEntity owner) {
        return UnstoppableDamageHandler.createStrikeSource(level, getItem(), magicStrikeType(), this, owner);
    }

    private float strikeAmount(float base) {
        return UnstoppableDamageHandler.breakAmount(getItem(), base);
    }

    public void absorbSpirits(List<ItemStack> spirits) {
        spiritStorage.addSpirits(spirits);
        if (getOwner() instanceof ServerPlayer player) {
            SpiritStorageHandler.storeForPlayer(player, spiritStorage);
        }
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.SUNDERING_ANCHOR.get();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag compound) {
        super.addAdditionalSaveData(compound);
        if (damage != 0) {
            compound.putFloat("damage", damage);
        }
        if (magicDamage != 0) {
            compound.putFloat("magicDamage", magicDamage);
        }
        if (age != 0) {
            compound.putInt("age", age);
        }
        if (reboundDelay != 0) {
            compound.putInt("reboundDelay", reboundDelay);
        }
        if (bounceCount != 0) {
            compound.putInt("bounceCount", bounceCount);
        }
        if (isReturning) {
            compound.putBoolean("isReturning", true);
        }
        if (returnTimer != 0) {
            compound.putInt("returnTimer", returnTimer);
        }
        if (slot != 0) {
            compound.putInt("slot", slot);
        }
        if (splitsRemaining != 0) {
            compound.putInt("splitsRemaining", splitsRemaining);
        }
        if (isClone()) {
            compound.putBoolean("isClone", true);
            compound.putInt("cloneLifetime", cloneLifetime);
        }
        if (pierceLevel != 0) {
            compound.putInt("pierceLevel", pierceLevel);
        }
        if (gatherLevel != 0) {
            compound.putInt("gatherLevel", gatherLevel);
        }
        if (piercing) {
            compound.putBoolean("piercing", true);
            compound.putInt("pierceHitsRemaining", pierceHitsRemaining);
            compound.putDouble("pierceX", pierceDirection.x);
            compound.putDouble("pierceY", pierceDirection.y);
            compound.putDouble("pierceZ", pierceDirection.z);
        }
        if (gatherTriggered) {
            compound.putBoolean("gatherTriggered", true);
        }
        if (violenceLevel != 0) {
            compound.putInt("violenceLevel", violenceLevel);
            compound.putInt("violenceAge", violenceAge);
        }
        if (kineticLevel != 0) {
            compound.putInt("kineticLevel", kineticLevel);
        }
        if (bounceDamageBonus != 0) {
            compound.putFloat("bounceDamageBonus", bounceDamageBonus);
        }
        if (!spiritStorage.isEmpty()) {
            compound.put("storedSpirits", spiritStorage.toTag());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag compound) {
        super.readAdditionalSaveData(compound);
        damage = compound.getFloat("damage");
        magicDamage = compound.getFloat("magicDamage");
        age = compound.getInt("age");
        reboundDelay = compound.getInt("reboundDelay");
        bounceCount = compound.getInt("bounceCount");
        isReturning = compound.getBoolean("isReturning");
        returnTimer = compound.getInt("returnTimer");
        slot = compound.getInt("slot");
        splitsRemaining = compound.getInt("splitsRemaining");
        setClone(compound.getBoolean("isClone"));
        cloneLifetime = compound.getInt("cloneLifetime");
        pierceLevel = compound.getInt("pierceLevel");
        gatherLevel = compound.getInt("gatherLevel");
        piercing = compound.getBoolean("piercing");
        pierceHitsRemaining = compound.getInt("pierceHitsRemaining");
        pierceDirection = new Vec3(compound.getDouble("pierceX"), compound.getDouble("pierceY"), compound.getDouble("pierceZ"));
        gatherTriggered = compound.getBoolean("gatherTriggered");
        violenceLevel = compound.getInt("violenceLevel");
        violenceAge = compound.getInt("violenceAge");
        kineticLevel = compound.getInt("kineticLevel");
        bounceDamageBonus = compound.getFloat("bounceDamageBonus");
        if (compound.contains("storedSpirits")) {
            spiritStorage = SpiritStorage.fromTag(compound.getCompound("storedSpirits"));
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        revalidateTarget();
        bounce();
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        if (isReturning) {
            return;
        }
        if (piercing) {
            if (level() instanceof ServerLevel serverLevel) {
                turnAround(serverLevel);
            } else {
                pierceDirection = pierceDirection.scale(-1);
            }
            setDeltaMovement(pierceDirection.scale(PIERCE_SPEED));
            return;
        }
        if (gatherLevel > 0 && !gatherTriggered && level() instanceof ServerLevel serverLevel) {
            gatherTriggered = true;
            performGather(serverLevel, result.getLocation());
        }
        if (forcedTarget != null && forcedTarget.isAlive()) {
            if (position().distanceTo(forcedTarget.position()) < 2f) {
                return;
            }
        }
        super.onHitBlock(result);
        if (result.getDirection().getAxis().isVertical()) {
            setDeltaMovement(getDeltaMovement().multiply(1, -1, 1));
        } else if (result.getDirection().getAxis().equals(net.minecraft.core.Direction.Axis.X)) {
            setDeltaMovement(getDeltaMovement().multiply(-1, 1, 1));
        } else if (result.getDirection().getAxis().equals(net.minecraft.core.Direction.Axis.Z)) {
            setDeltaMovement(getDeltaMovement().multiply(1, 1, -1));
        }
        jumbleMovement(0.2f);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if (level() instanceof ServerLevel level) {
            hitTarget(level, result.getEntity());
        }
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        return false;
    }

    protected boolean canHitEntityCustom(Entity target) {
        if (target.equals(getOwner())) {
            return false;
        }
        if (target instanceof SunderingAnchorProjectile) {
            return false;
        }
        if (ignoredTargets.contains(target)) {
            return false;
        }
        if (hitCount.getInt(target) >= 5) {
            return false;
        }
        return super.canHitEntity(target);
    }

    @Override
    public void tick() {
        Vec3 deltaMovement = getDeltaMovement();
        super.tick();
        setDeltaMovement(getDeltaMovement().normalize().scale(deltaMovement.length()));

        age++;
        returnTimer++;
        violenceAge++;
        if (level() instanceof ServerLevel level) {
            if (isClone() && --cloneLifetime <= 0) {
                SoundHelper.playSound(this, ModSounds.SUNDERING_ANCHOR_EXTRA_SWING.get(), 0.6f, 1.6f);
                remove(RemovalReason.DISCARDED);
                return;
            }
            if (piercing) {
                tickPiercing(level);
                return;
            }
            var aabb = getBoundingBox().inflate(2);
            for (Entity target : level.getEntities(this, aabb, this::canHitEntityCustom)) {
                if (getOwner() instanceof LivingEntity owner && target.isAlliedTo(owner)) {
                    continue;
                }
                onHit(new EntityHitResult(target));
            }
            if (age % 20 == 0) {
                revalidateTarget();
                selectNearestTarget(level);
            }
            if (isReturning) {
                if (getOwner() instanceof LivingEntity owner) {
                    var ownerPos = owner.position().add(0, owner.getBbHeight() * 0.6f, 0);
                    float velocityLimit = 3f;
                    var motion = getDeltaMovement();
                    double velocity = Mth.clamp(motion.length() * 1.25f, 0.5f, velocityLimit);
                    var returnMotion = ownerPos.subtract(position()).normalize().scale(velocity);
                    setDeltaMovement(motion.lerp(returnMotion, 0.3f));

                    if (isAlive() && distanceTo(owner) < 2.5f) {
                        SoundHelper.playSound(owner, com.sammy.malum.registry.common.SoundRegistry.SCYTHE_CATCH.get(), 0.5f, RandomHelper.randomBetween(level.random, 1.5f, 2f));
                        if (owner instanceof ServerPlayer player) {
                            float cooldownScalar = hitCount.isEmpty() ? 0.25f : 1f;
                            grantStolenEffects(player);
                            TemporarilyDisabledItem.enable(player, slot);
                            SunderingAnchorItem.applyCooldown(getItem(), player, cooldownScalar);
                        }
                        remove(RemovalReason.DISCARDED);
                    }
                }
            } else {
                if (!isClone() && shouldReturnToOwner(level)) {
                    returnToOwner();
                }
                if (reboundDelay > 0) {
                    reboundDelay--;
                    if (reboundDelay == 0) {
                        selectNearestTarget(level);
                    }
                }
                applyAqueousBoost();
                homeIn(level);
            }
        } else {
            if (!isClone()) {
                spawnParticles();
            }
            Vec3 projectileDirection = getDeltaMovement().normalize();
            float yRot = ((float) (Mth.atan2(projectileDirection.x, projectileDirection.z) * (double) (180F / (float) Math.PI)));
            float yaw = (float) Math.toRadians(yRot);
            Vec3 left = new Vec3(-Math.cos(yaw), 0, Math.sin(yaw));
            Vec3 up = left.cross(projectileDirection);
            Vec3 newMotion = left.scale(0.1f - random.nextFloat() * 0.2f).add(up.scale(0.1f - random.nextFloat() * 0.2f));
            setDeltaMovement(getDeltaMovement().lerp(newMotion, 0.2f));
            if (isClone()) {
                return;
            }
            float offsetScale = Mth.clampedLerp(0.1f, 0.3f, getVisualEffectScalar());
            for (int i = 0; i < 2; i++) {
                float progress = (i + 1) * 0.5f;
                Vec3 position = getPosition(progress);
                float scalar = (age + progress) / 2f;
                double xOffset = Math.cos(spinOffset + scalar) * offsetScale;
                double zOffset = Math.sin(spinOffset + scalar) * offsetScale;
                trailPointBuilder.addTrailPoint(position);
                spinningTrailPointBuilder.addTrailPoint(position.add(left.scale(xOffset)).add(up.scale(zOffset)));
            }
            trailPointBuilder.tickTrailPoints();
            spinningTrailPointBuilder.tickTrailPoints();
        }
    }

    @Override
    public SoundSource getSoundSource() {
        return getOwner() != null ? getOwner().getSoundSource() : SoundSource.PLAYERS;
    }

    @Override
    public void shootFromRotation(Entity shooter, float rotationPitch, float rotationYaw, float pitchOffset, float velocity, float innacuracy) {
        float f = -Mth.sin(rotationYaw * ((float) Math.PI / 180F)) * Mth.cos(rotationPitch * ((float) Math.PI / 180F));
        float f1 = -Mth.sin((rotationPitch + pitchOffset) * ((float) Math.PI / 180F));
        float f2 = Mth.cos(rotationYaw * ((float) Math.PI / 180F)) * Mth.cos(rotationPitch * ((float) Math.PI / 180F));
        this.shoot(f, f1, f2, velocity, innacuracy);
    }

    public void jumbleMovement(float weight) {
        float randomRotationX = (float) (Math.random() * Math.PI * 2);
        float randomRotationY = (float) (Math.random() * Math.PI * 2);
        float randomRotationZ = (float) (Math.random() * Math.PI * 2);
        Vec3 motion = getDeltaMovement();
        Vec3 newMotion = motion.xRot(randomRotationX).yRot(randomRotationY);
        double cosZ = Math.cos(randomRotationZ);
        double sinZ = Math.sin(randomRotationZ);
        double x = newMotion.x * cosZ - newMotion.y * sinZ;
        double y = newMotion.x * sinZ + newMotion.y * cosZ;
        double z = newMotion.z;
        final Vec3 lerp = motion.lerp(new Vec3(x, y, z), weight);
        setDeltaMovement(lerp.normalize().scale(motion.length()));
    }

    public void selectNearestTarget(ServerLevel level) {
        Entity owner = getOwner();
        if (owner == null) {
            return;
        }
        List<LivingEntity> entities = getTargets(level, target -> hitCount.getInt(target) < 5);
        if (entities.isEmpty()) {
            forcedTarget = null;
            returnToOwner();
            return;
        }
        if (entities.size() == 1) {
            forcedTarget = entities.get(0);
        } else {
            forcedTarget = entities.stream().filter(e -> !ignoredTargets.contains(e))
                    .min(Comparator.comparingDouble(this::distanceToSqr)).orElse(null);
        }
        if (forcedTarget != null) {
            var speed = getDeltaMovement().length();
            for (int i = 0; i < 3; i++) {
                var distance = forcedTarget.position().subtract(position());
                var newMotion = getDeltaMovement().lerp(distance.normalize(), 0.3f);
                setDeltaMovement(newMotion.normalize());
            }
            setDeltaMovement(getDeltaMovement().scale(speed));
        }
    }

    private static LivingEntity resolveLivingTarget(Entity target) {
        if (target instanceof LivingEntity living) {
            return living;
        }
        if (target instanceof PartEntity<?> part && part.getParent() instanceof LivingEntity parent) {
            return parent;
        }
        return null;
    }

    public void hitTarget(ServerLevel level, Entity target) {
        LivingEntity livingTarget = resolveLivingTarget(target);
        if (livingTarget == null || livingTarget.isRemoved()) {
            return;
        }
        if (getOwner() instanceof LivingEntity owner) {
            ignoredTargets.add(target);
            hitCount.addTo(target, 1);
            target.invulnerableTime = 0;
            DamageSource source = strikeSource(level, owner);
            boolean headshot = isHeadshot(target);
            float headshotMultiplier = headshot ? HEADSHOT_DAMAGE_MULTIPLIER : 1f;
            livingTarget.invulnerableTime = 0;
            UnstoppableDamageHandler.forcePierce(livingTarget, source, strikeAmount(headshotMultiplier));
            if (livingTarget.isAlive()) {
                int slashCount = 5;
                int delay = 8;
                float proficiency = SunderingAnchorItem.getScytheProficiency(owner);
                float multiplier = proficiency * (headshot ? HEADSHOT_DAMAGE_MULTIPLIER : 1f);
                SoundHelper.playSound(this, ModSounds.SUNDERING_ANCHOR_SWING.get(), 2f, RandomHelper.randomBetween(level.random, 1.5f, 2f));
                if (headshot) {
                    spawnHeadshotCriticalFeedback(level, livingTarget);
                }
                SunderingAnchorItem.applyHatred(livingTarget);
                AnchorComboHandler.scheduleProjectileCombo(level, owner, livingTarget,
                        getBoostedDamage() * multiplier / slashCount, getBoostedMagic() * multiplier / slashCount, slashCount, delay,
                        strikeType(), magicStrikeType(), getItem(), !isClone());
                applySpiritStorageAbilities(level, owner, livingTarget);
                selectNearestTarget(level);
                jumbleMovement(0.8f);
                performSplit(level, target);
                startPiercingIfPossible(level, target, owner);
            }
        }
    }

    private float getBoostedDamage() {
        return damage * (1f + bounceDamageBonus + spiritStorage.bonus(SpiritTypeRegistry.INFERNAL_SPIRIT));
    }

    private float getBoostedMagic() {
        return Math.max(magicDamage * (1f + spiritStorage.bonus(SpiritTypeRegistry.ELDRITCH_SPIRIT)) - 1, 0.25f);
    }

    private void applySpiritStorageAbilities(ServerLevel level, LivingEntity owner, LivingEntity target) {
        if (spiritStorage.isEmpty()) {
            return;
        }
        if (spiritStorage.bonus(SpiritTypeRegistry.INFERNAL_SPIRIT) > 0) {
            target.setSecondsOnFire(4);
        }
        if (spiritStorage.bonus(SpiritTypeRegistry.SACRED_SPIRIT) > 0) {
            stealPositiveEffect(target);
        }
        float penetration = spiritStorage.bonus(SpiritTypeRegistry.ARCANE_SPIRIT);
        if (isInWater()) {
            penetration += spiritStorage.bonus(SpiritTypeRegistry.AQUEOUS_SPIRIT);
        }
        float extraDamage = getBoostedMagic() * penetration
                + (getBoostedDamage() + getBoostedMagic()) * spiritStorage.bonus(SpiritTypeRegistry.UMBRAL_SPIRIT);
        if (extraDamage > 0) {
                UnstoppableDamageHandler.forcePierce(target, magicStrikeSource(level, owner), strikeAmount(extraDamage));
            }
    }

    private void stealPositiveEffect(LivingEntity target) {
        List<MobEffectInstance> beneficial = new ArrayList<>();
        for (MobEffectInstance effect : target.getActiveEffects()) {
            if (effect.getEffect().isBeneficial()) {
                beneficial.add(effect);
            }
        }
        if (beneficial.isEmpty()) {
            return;
        }
        MobEffectInstance stolen = beneficial.get(random.nextInt(beneficial.size()));
        target.removeEffect(stolen.getEffect());
        int duration = Math.max(20, (int) (stolen.getDuration() * (1f + spiritStorage.bonus(SpiritTypeRegistry.SACRED_SPIRIT))));
        MobEffectInstance stored = new MobEffectInstance(stolen.getEffect(), duration, stolen.getAmplifier(),
                stolen.isAmbient(), stolen.isVisible(), stolen.showIcon());
        for (int i = 0; i < stolenEffects.size(); i++) {
            if (stolenEffects.get(i).getEffect() == stored.getEffect()) {
                if (stolenEffects.get(i).getDuration() < duration) {
                    stolenEffects.set(i, stored);
                }
                return;
            }
        }
        if (stolenEffects.size() < MAX_STOLEN_EFFECTS) {
            stolenEffects.add(stored);
        }
    }

    private void grantStolenEffects(ServerPlayer player) {
        for (MobEffectInstance effect : stolenEffects) {
            player.addEffect(new MobEffectInstance(effect));
        }
        stolenEffects.clear();
    }

    private void applyAqueousBoost() {
        float bonus = spiritStorage.bonus(SpiritTypeRegistry.AQUEOUS_SPIRIT);
        if (bonus <= 0 || !isInWater()) {
            return;
        }
        Vec3 motion = getDeltaMovement();
        double speed = motion.length();
        if (speed < 1.0E-4) {
            return;
        }
        double target = AQUEOUS_BASE_SPEED * (1 + bonus);
        if (speed < target) {
            setDeltaMovement(motion.normalize().scale(Math.min(target, speed + AQUEOUS_ACCELERATION)));
        }
    }

    private void performSplit(ServerLevel level, Entity hitTarget) {
        if (splitsRemaining <= 0) {
            return;
        }
        splitsRemaining--;
        LivingEntity owner = getOwner() instanceof LivingEntity living ? living : null;
        SunderingAnchorProjectile clone = new SunderingAnchorProjectile(level, getX(), getY() + 0.5, getZ());
        clone.setData(owner, damage, magicDamage, -1);
        clone.setItem(getItem());
        clone.setClone(true);
        clone.splitsRemaining = splitsRemaining;
        clone.cloneLifetime = CLONE_LIFETIME;
        clone.pierceLevel = this.pierceLevel;
        clone.kineticLevel = this.kineticLevel;
        clone.bounceDamageBonus = this.bounceDamageBonus;
        clone.spiritStorage = this.spiritStorage.copy();
        Vec3 direction = new Vec3(hitTarget.getX() - getX(), hitTarget.getEyeY() - getEyeY(), hitTarget.getZ() - getZ()).normalize();
        clone.setDeltaMovement(direction.scale(1.8).add(0, 0.25, 0));
        level.addFreshEntity(clone);

        SoundHelper.playSound(this, ModSounds.SUNDERING_ANCHOR_EXTRA_SWING.get(), 1f, RandomHelper.randomBetween(level.random, 1.3f, 1.7f));
        var spirit = SunderingAnchorItem.getSunderingAnchorSpirit();
        ModParticleEffectTypes.SUNDERING_ANCHOR_SWEEP.createPositionedEffect(level,
                new PositionEffectData(position()), new ColorEffectData(spirit),
                net.lust1212.lingzai_rebirth.visual_effects.SunderingAnchorSweepParticleEffect.createData(spirit));
    }

    private void startPiercingIfPossible(ServerLevel level, Entity firstTarget, LivingEntity owner) {
        if (pierceLevel <= 0 || piercing) {
            return;
        }
        piercing = true;
        pierceHitsRemaining = PIERCE_HITS;
        pierceTravel = 0;
        pierceAge = 0;
        piercedThisPass.clear();
        pierceDirection = computePierceDirection(level, firstTarget, owner);
        pierceTarget = firstTarget instanceof LivingEntity living && living.isAlive() ? living : null;
        setDeltaMovement(pierceDirection.scale(PIERCE_SPEED));
        SoundHelper.playSound(this, ModSounds.SUNDERING_ANCHOR_SWING.get(), 2f, 0.6f);
    }

    private Vec3 computePierceDirection(ServerLevel level, Entity firstTarget, LivingEntity owner) {
        Vec3 origin = position();
        List<LivingEntity> candidates = new ArrayList<>(level.getEntitiesOfClass(LivingEntity.class,
                getBoundingBox().inflate(PIERCE_SCAN_RADIUS),
                entity -> entity != owner && entity.isAlive() && !entity.isAlliedTo(owner)));
        Vec3 fallback = firstTarget.position().add(0, firstTarget.getBbHeight() * 0.5, 0).subtract(origin).normalize();
        if (candidates.isEmpty()) {
            return fallback;
        }
        Vec3 best = Vec3.ZERO;
        int bestCount = -1;
        for (LivingEntity candidate : candidates) {
            Vec3 toCandidate = candidate.position().add(0, candidate.getBbHeight() * 0.5, 0).subtract(origin);
            if (toCandidate.lengthSqr() < 1.0E-4) {
                continue;
            }
            Vec3 direction = toCandidate.normalize();
            int count = 0;
            for (LivingEntity other : candidates) {
                Vec3 toOther = other.position().add(0, other.getBbHeight() * 0.5, 0).subtract(origin);
                double along = toOther.dot(direction);
                if (along <= 0 || along > PIERCE_PASS_RANGE) {
                    continue;
                }
                if (toOther.subtract(direction.scale(along)).length() <= PIERCE_CORRIDOR) {
                    count++;
                }
            }
            if (count > bestCount) {
                bestCount = count;
                best = direction;
            }
        }
        return best.lengthSqr() < 1.0E-4 ? fallback : best;
    }

    private void tickPiercing(ServerLevel level) {
        pierceAge++;
        if (pierceTarget == null || !pierceTarget.isAlive() || pierceTarget.level() != level() || distanceTo(pierceTarget) > 48f) {
            pierceTarget = pickPierceTarget(level);
        }
        pierceTravel += getDeltaMovement().length();
        if (pierceTravel >= PIERCE_PASS_RANGE) {
            turnAround(level);
        }
        if (pierceTarget != null) {
            Vec3 toTarget = pierceTarget.position().add(0, pierceTarget.getBbHeight() * 0.5, 0).subtract(position());
            if (toTarget.lengthSqr() > 1.0E-4) {
                pierceDirection = pierceDirection.normalize().add(toTarget.normalize().scale(PIERCE_HOMING)).normalize();
            }
        }
        setDeltaMovement(pierceDirection.scale(PIERCE_SPEED));

        for (Entity target : level.getEntities(this, getBoundingBox().inflate(PIERCE_CORRIDOR), this::canPierceHit)) {
            hitPierceTarget(level, target);
            if (!piercing) {
                return;
            }
        }
        if (pierceAge >= PIERCE_MAX_TICKS) {
            endPiercing();
        }
    }

    private void turnAround(ServerLevel level) {
        pierceTravel = 0;
        piercedThisPass.clear();
        if (pierceTarget == null || !pierceTarget.isAlive()) {
            pierceTarget = pickPierceTarget(level);
        }
        if (pierceTarget != null) {
            Vec3 toTarget = pierceTarget.position().add(0, pierceTarget.getBbHeight() * 0.5, 0).subtract(position());
            if (toTarget.lengthSqr() > 1.0E-4) {
                pierceDirection = toTarget.normalize();
                return;
            }
        }
        pierceDirection = pierceDirection.scale(-1);
    }

    private LivingEntity pickPierceTarget(ServerLevel level) {
        return level.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(PIERCE_SCAN_RADIUS), this::canPierceHit)
                .stream().min(Comparator.comparingDouble(this::distanceToSqr)).orElse(null);
    }

    private void endPiercing() {
        piercing = false;
        pierceTarget = null;
        piercedThisPass.clear();
        returnTimer = Math.max(returnTimer, 100);
        bounceCount = Math.max(bounceCount, 20);
    }

    private boolean canPierceHit(Entity target) {
        if (target.equals(getOwner()) || target instanceof SunderingAnchorProjectile) {
            return false;
        }
        if (!(target instanceof LivingEntity living) || !living.isAlive() || living.isDeadOrDying()) {
            return false;
        }
        if (getOwner() != null && target.isAlliedTo(getOwner())) {
            return false;
        }
        if (target instanceof TamableAnimal tamable && tamable.isTame()) {
            return false;
        }
        return !piercedThisPass.contains(target);
    }

    private void hitPierceTarget(ServerLevel level, Entity target) {
        if (!(getOwner() instanceof LivingEntity owner) || !(target instanceof LivingEntity living)) {
            return;
        }
        float proficiency = SunderingAnchorItem.getScytheProficiency(owner);
        float total = (getBoostedDamage() + getBoostedMagic()) * proficiency;
        if (total <= 0) {
            return;
        }
        piercedThisPass.add(target);
        float half = total / 2f;
        UnstoppableDamageHandler.forcePierce(living, magicStrikeSource(level, owner), strikeAmount(half));
        UnstoppableDamageHandler.forcePierce(living, strikeSource(level, owner), strikeAmount(half));
        SunderingAnchorItem.applyHatred(living);
        SoundHelper.playSound(this, ModSounds.SUNDERING_ANCHOR_PROJECTILE_SWING.get(), 1.5f, 0.8f);
        var spirit = SunderingAnchorItem.getSunderingAnchorSpirit();
        ModParticleEffectTypes.SUNDERING_ANCHOR_SWEEP.createEntityEffect(living, new ColorEffectData(spirit),
                net.lust1212.lingzai_rebirth.visual_effects.SunderingAnchorSweepParticleEffect.createData(spirit));
        if (--pierceHitsRemaining <= 0) {
            endPiercing();
        }
    }

    private void performGather(ServerLevel level, Vec3 impact) {
        if (!(getOwner() instanceof LivingEntity owner)) {
            return;
        }
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, new AABB(impact, impact).inflate(GATHER_RADIUS),
                entity -> !(entity instanceof Player) && entity.isAlive() && !entity.isAlliedTo(owner));
        int count = targets.size();
        float proficiency = SunderingAnchorItem.getScytheProficiency(owner);
        float magic = Math.max(magicDamage - 1, 0.25f) * proficiency;
        int index = 0;
        for (LivingEntity target : targets) {
            double angle = count <= 1 ? 0 : (double) index / count * Math.PI * 2;
            target.teleportTo(impact.x + Math.cos(angle) * GATHER_RING_RADIUS, impact.y, impact.z + Math.sin(angle) * GATHER_RING_RADIUS);
            target.resetFallDistance();
            UnstoppableDamageHandler.forcePierce(target, strikeSource(level, owner), strikeAmount(damage * proficiency));
            if (magic > 0) {
                UnstoppableDamageHandler.forcePierce(target, magicStrikeSource(level, owner), strikeAmount(magic));
            }
            SunderingAnchorItem.applyHatred(target);
            index++;
        }
        SoundHelper.playSound(this, ModSounds.WORLDSOUL_MOTIF_HEAVY_IMPACT.get(), 1.5f, 1.1f);
        var spirit = SunderingAnchorItem.getSunderingAnchorSpirit();
        ModParticleEffectTypes.SUNDERING_ANCHOR_SWEEP.createPositionedEffect(level, new PositionEffectData(impact),
                new ColorEffectData(spirit),
                net.lust1212.lingzai_rebirth.visual_effects.SunderingAnchorSweepParticleEffect.createData(spirit));
    }

    public boolean isHeadshot(Entity target) {
        double headZoneY = target.getY() + target.getBbHeight() * HEADSHOT_THRESHOLD;
        return position().y >= headZoneY;
    }

    public void spawnHeadshotCriticalFeedback(ServerLevel level, LivingEntity target) {
        Vec3 hitPos = position().add(0, target.getBbHeight() * 0.5f, 0);
        level.sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT, hitPos.x, hitPos.y, hitPos.z, 12, 0.25, 0.25, 0.25, 0.15);
        SoundHelper.playSound(this, net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_CRIT, 1.25f, RandomHelper.randomBetween(level.random, 1.1f, 1.4f));
    }

    public void homeIn(ServerLevel level) {
        Vec3 motion = getDeltaMovement();
        Entity owner = getOwner();
        if (owner == null) {
            return;
        }
        Entity nearest;
        boolean demandAccuracy = true;

        if (forcedTarget != null && forcedTarget.isAlive() && !ignoredTargets.contains(forcedTarget)) {
            nearest = forcedTarget;
            demandAccuracy = false;
        } else if (owner.position().distanceTo(position()) > 30f) {
            nearest = owner;
            demandAccuracy = false;
        } else {
            List<LivingEntity> targets = getTargets(level, target -> !ignoredTargets.contains(target) && hitCount.getInt(target) < 5);
            nearest = targets.stream().min(Comparator.comparingDouble(this::distanceToSqr)).orElse(null);
        }
        if (nearest != null) {
            Vec3 nearestPosition = nearest.position().add(0, nearest.getBbHeight() * LOCK_ON_AIM_HEIGHT, 0);
            Vec3 distance = nearestPosition.subtract(position());
            double speed = motion.length();
            Vec3 nextPosition = position().add(getDeltaMovement());
            if (demandAccuracy && nearest.distanceToSqr(nextPosition) > nearest.distanceToSqr(position())) {
                return;
            }
            Vec3 newMotion = distance.normalize();
            double dot = motion.normalize().dot(distance.normalize());
            if (demandAccuracy && dot < 0.1f) {
                return;
            }
            if (newMotion.length() == 0) {
                newMotion = newMotion.add(0.01, 0, 0);
            }
            float angleScalar = Math.max(((Mth.abs((float) (0.5f - dot)) - 0.2f) * 2.5f), 0.4f);
            float factor = 0.125f * angleScalar;
            if (!demandAccuracy) {
                factor = Mth.clamp((float) (1 - distance.length() / 80f) * 2f, 0.1f, 0.5f);
            }
            final double x = Mth.clampedLerp(motion.x, newMotion.x, factor);
            final double y = Mth.clampedLerp(motion.y, newMotion.y, factor);
            final double z = Mth.clampedLerp(motion.z, newMotion.z, factor);
            setDeltaMovement(new Vec3(x, y, z).normalize().scale(speed));
        }
    }

    public List<LivingEntity> getTargets(ServerLevel level, Predicate<LivingEntity> extraFilter) {
        Entity owner = getOwner();
        if (owner == null) {
            return Collections.emptyList();
        }
        var aabb = getBoundingBox().inflate(30);
        var targets = level.getEntitiesOfClass(LivingEntity.class, aabb,
                target -> isValidTarget(level, target, owner) && extraFilter.test(target));

        if (!targets.stream().allMatch(t -> t instanceof Player)) {
            targets.removeIf(t -> t instanceof Player player && !player.hasEffect(ModMobEffects.HATRED.get()));
        }
        return targets;
    }

    public boolean isValidTarget(ServerLevel level, LivingEntity target, Entity owner) {
        if (target == owner) {
            return false;
        }
        if (target.isDeadOrDying()) {
            return false;
        }
        if (target.isAlliedTo(owner)) {
            return false;
        }
        if (target instanceof TamableAnimal tamableAnimal) {
            if (tamableAnimal.isTame()) {
                return false;
            }
        }
        return hasLineOfSight(level, target);
    }

    public void returnToOwner() {
        if (isClone()) {
            return;
        }
        if (age > 30) {
            isReturning = true;
        }
    }

    private boolean shouldReturnToOwner(ServerLevel level) {
        if (violenceLevel > 0) {
            if (violenceAge >= (long) violenceLevel * VIOLENCE_TICKS_PER_LEVEL) {
                return true;
            }
            return getTargets(level, target -> hitCount.getInt(target) < 5).isEmpty();
        }
        float durationBonus = spiritStorage.bonus(SpiritTypeRegistry.WICKED_SPIRIT);
        int maxBounces = Math.round(20 * (1f + durationBonus));
        int maxReturnTimer = Math.round(80 * (1f + durationBonus));
        return bounceCount >= maxBounces || returnTimer > maxReturnTimer;
    }

    public void bounce() {
        bounceCount++;
        reboundDelay = 3;
        returnTimer -= 10;
        float speedScalar = 1f;
        if (kineticLevel > 0) {
            speedScalar += KINETIC_SPEED_PER_BOUNCE;
            bounceDamageBonus = Math.min(KINETIC_MAX_DAMAGE_BONUS, bounceDamageBonus + KINETIC_DAMAGE_PER_BOUNCE);
        }
        float earthen = spiritStorage.bonus(SpiritTypeRegistry.EARTHEN_SPIRIT);
        if (earthen > 0) {
            speedScalar += earthen * EARTHEN_BOUNCE_SPEED_SCALE;
        }
        if (speedScalar != 1f) {
            setDeltaMovement(getDeltaMovement().scale(speedScalar));
        }
    }

    public void revalidateTarget() {
        if (!ignoredTargets.isEmpty()) {
            float chance = 0.8f - ignoredTargets.size() * 0.1f;
            if (random.nextFloat() < chance) {
                ignoredTargets.remove(ignoredTargets.get(random.nextInt(ignoredTargets.size())));
            }
        }
    }

    public boolean hasLineOfSight(ServerLevel level, Entity target) {
        Vec3 wrathPosition = new Vec3(getX(), getEyeY(), getZ());
        Vec3 targetPosition = new Vec3(target.getX(), target.getEyeY(), target.getZ());
        var clipResult = level.clip(new ClipContext(wrathPosition, targetPosition, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        return clipResult.getType().equals(HitResult.Type.MISS);
    }

    public float getVisualEffectScalar() {
        float effectScalar = 1;
        if (age < 8) {
            effectScalar = age / 8f;
        }
        return effectScalar;
    }

    @OnlyIn(Dist.CLIENT)
    public void spawnParticles() {
        Level level = level();
        float scalar = getVisualEffectScalar();
        Vec3 norm = getDeltaMovement().normalize().scale(0.05f);
        MalumSpiritType spirit = SunderingAnchorItem.getSunderingAnchorSpirit();
        var lightSpecs = SpiritLightSpecs.spiritLightSpecs(level, position(), spirit);
        lightSpecs.getBuilder()
                .setRenderTarget(RenderHandler.LATE_DELAYED_RENDER)
                .multiplyLifetime(5f)
                .setMotion(norm);
        lightSpecs.getBloomBuilder()
                .setRenderTarget(RenderHandler.LATE_DELAYED_RENDER)
                .multiplyLifetime(5f)
                .setMotion(norm);
        lightSpecs.spawnParticles();
        final Consumer<team.lodestar.lodestone.systems.particle.world.LodestoneWorldParticle> behavior =
                p -> p.setParticleSpeed(p.getParticleSpeed().scale(0.95f));

        float count = 1 + (float) getDeltaMovement().length() * 3;
        for (int i = 0; i < count; i++) {
            spirit = SunderingAnchorItem.getSunderingAnchorSpirit();
            Vec3 position = getPosition(i / count);
            WorldParticleBuilder.create(ModParticles.ROUNDABOUT_SLASH, new PointyDirectionalBehaviorComponent(getDeltaMovement().normalize()))
                    .setTransparencyData(GenericParticleData.create(0.9f * scalar, 0.7f * scalar, 0f).setEasing(Easing.SINE_IN_OUT, Easing.SINE_IN).build())
                    .setSpinData(SpinParticleData.createRandomDirection(random, RandomHelper.randomBetween(random, 0.25f, 0.5f)).randomSpinOffset(random).build())
                    .setScaleData(GenericParticleData.create(0.2f * scalar, 0.4f * scalar).setEasing(Easing.SINE_IN_OUT).build())
                    .setSpritePicker(SimpleParticleOptions.ParticleSpritePicker.WITH_AGE)
                    .setRenderTarget(RenderHandler.LATE_DELAYED_RENDER)
                    .setColorData(spirit.createColorData().build())
                    .setLifetime(Math.min(5 + age * 2, 20))
                    .addTickActor(behavior)
                    .enableForcedSpawn()
                    .enableNoClip()
                    .spawn(level, position.x, position.y, position.z)
                    .setScaleData(GenericParticleData.create(0.3f * scalar, 0.5f * scalar).setEasing(Easing.SINE_IN_OUT).build())
                    .setTransparencyData(GenericParticleData.create(0.6f * scalar, 0.5f * scalar, 0f).setEasing(Easing.SINE_IN_OUT, Easing.SINE_IN).build())
                    .setRenderType(LodestoneWorldParticleRenderType.LUMITRANSPARENT)
                    .setColorData(ColorParticleData.create(ColorHelper.darker(spirit.getPrimaryColor(), 2)).build())
                    .spawn(level, position.x, position.y, position.z);
        }
    }

    @Override
    public boolean isNoGravity() {
        return true;
    }

    @Override
    public float getPickRadius() {
        return 4f;
    }

    @Override
    public boolean fireImmune() {
        return true;
    }

    @Override
    public boolean ignoreExplosion() {
        return true;
    }
}