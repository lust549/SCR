package net.lust1212.lingzai_rebirth.visual_effects;

import com.sammy.malum.core.systems.spirit.MalumSpiritType;
import com.sammy.malum.registry.common.SpiritTypeRegistry;
import com.sammy.malum.visual_effects.SpiritLightSpecs;
import com.sammy.malum.visual_effects.networked.ParticleEffectType;
import net.lust1212.lingzai_rebirth.registry.ModParticles;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import team.lodestar.lodestone.handlers.RenderHandler;
import team.lodestar.lodestone.helpers.RandomHelper;
import team.lodestar.lodestone.systems.easing.Easing;
import team.lodestar.lodestone.systems.particle.builder.WorldParticleBuilder;
import team.lodestar.lodestone.systems.particle.data.GenericParticleData;
import team.lodestar.lodestone.systems.particle.render_types.LodestoneWorldParticleRenderType;
import team.lodestar.lodestone.systems.particle.world.behaviors.components.SparkBehaviorComponent;

import java.util.function.Supplier;

public class EntropicBoltImpactParticleEffect extends ParticleEffectType {

    public EntropicBoltImpactParticleEffect(String id) {
        super(id);
    }

    @OnlyIn(Dist.CLIENT)
    @Override
    public Supplier<ParticleEffectActor> get() {
        return () -> (level, random, positionData, colorData, nbtData) -> {
            Vec3 pos = positionData.getAsVector();
            MalumSpiritType spirit = SpiritTypeRegistry.AQUEOUS_SPIRIT;
            for (int i = 0; i < 32; i++) {
                float spread = RandomHelper.randomBetween(random, 0.05f, 0.075f);
                float speed = RandomHelper.randomBetween(random, 0.4f, 0.6f);
                float distance = RandomHelper.randomBetween(random, 4f, 12f);
                float angle = i / 32f * (float) Math.PI * 2f;
                Vec3 direction = new Vec3(Mth.sin(angle) * spread, RandomHelper.randomBetween(random, -0.1f, 0.1f), Mth.cos(angle) * spread)
                        .normalize().scale(speed);
                Vec3 spawnPosition = pos.add(direction.scale(distance));
                direction = direction.reverse();

                if (random.nextFloat() < 0.8f) {
                    var lightSpecs = SpiritLightSpecs.spiritLightSpecs(level, spawnPosition, spirit);
                    lightSpecs.getBuilder()
                            .multiplyLifetime(0.7f)
                            .enableForcedSpawn()
                            .setMotion(direction);
                    lightSpecs.getBloomBuilder()
                            .multiplyLifetime(0.7f)
                            .setMotion(direction);
                    lightSpecs.spawnParticles();
                }
                if (random.nextFloat() < 0.8f) {
                    WorldParticleBuilder.create(ModParticles.GIANT_ARROW, new SparkBehaviorComponent(GenericParticleData.create(1.2f, 0.1f).setEasing(Easing.CUBIC_IN).build()))
                            .setRenderTarget(RenderHandler.LATE_DELAYED_RENDER)
                            .setTransparencyData(GenericParticleData.create(0.6f, 0f).setEasing(Easing.SINE_IN_OUT, Easing.SINE_IN).build())
                            .setScaleData(GenericParticleData.create(0.8f, 0.2f).setEasing(Easing.SINE_IN_OUT).build())
                            .setColorData(com.sammy.malum.common.entity.nitrate.EthericNitrateEntity.AURIC_COLOR_DATA)
                            .setLifetime(10)
                            .setMotion(direction.scale(1.5f))
                            .enableForcedSpawn()
                            .enableNoClip()
                            .spawn(level, spawnPosition.x, spawnPosition.y, spawnPosition.z)
                            .setRenderType(LodestoneWorldParticleRenderType.LUMITRANSPARENT)
                            .spawn(level, spawnPosition.x, spawnPosition.y, spawnPosition.z);
                }
            }
        };
    }
}