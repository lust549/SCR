package net.lust1212.lingzai_rebirth;

import net.lust1212.lingzai_rebirth.registry.ModCreativeTabs;
import net.lust1212.lingzai_rebirth.registry.ModDamageTypes;
import net.lust1212.lingzai_rebirth.registry.ModEnchantments;
import net.lust1212.lingzai_rebirth.registry.ModEntities;
import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.lust1212.lingzai_rebirth.registry.ModMobEffects;
import net.lust1212.lingzai_rebirth.registry.ModParticleEffectTypes;
import net.lust1212.lingzai_rebirth.registry.ModParticles;
import net.lust1212.lingzai_rebirth.registry.ModSounds;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(SpiritCalamityRebirth.MOD_ID)
public class SpiritCalamityRebirth {
    public static final String MOD_ID = "lingzai_rebirth";

    @SuppressWarnings("removal")
    public SpiritCalamityRebirth() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modEventBus);
        ModEntities.ENTITIES.register(modEventBus);
        ModParticles.PARTICLES.register(modEventBus);
        ModSounds.SOUNDS.register(modEventBus);
        ModMobEffects.EFFECTS.register(modEventBus);
        ModEnchantments.ENCHANTMENTS.register(modEventBus);
        ModCreativeTabs.TABS.register(modEventBus);
        ModDamageTypes.init();
        ModParticleEffectTypes.init();
    }
}