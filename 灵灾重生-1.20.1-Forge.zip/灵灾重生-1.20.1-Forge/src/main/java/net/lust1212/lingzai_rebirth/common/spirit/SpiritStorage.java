package net.lust1212.lingzai_rebirth.common.spirit;

import com.sammy.malum.core.systems.spirit.MalumSpiritType;
import com.sammy.malum.registry.common.SpiritTypeRegistry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

import java.util.List;

public class SpiritStorage {

    public static final List<MalumSpiritType> TYPES = List.of(
            SpiritTypeRegistry.AERIAL_SPIRIT,
            SpiritTypeRegistry.AQUEOUS_SPIRIT,
            SpiritTypeRegistry.ARCANE_SPIRIT,
            SpiritTypeRegistry.EARTHEN_SPIRIT,
            SpiritTypeRegistry.ELDRITCH_SPIRIT,
            SpiritTypeRegistry.INFERNAL_SPIRIT,
            SpiritTypeRegistry.SACRED_SPIRIT,
            SpiritTypeRegistry.UMBRAL_SPIRIT,
            SpiritTypeRegistry.WICKED_SPIRIT);

    public static final String TAG_KEY = "StoredSpirits";
    public static final int SPIRITS_PER_GROUP = 64;
    private static final float BONUS_PER_GROUP = 0.01f;
    private static final float UMBRAL_BONUS_PER_GROUP = 0.001f;

    private final int[] counts = new int[TYPES.size()];

    public SpiritStorage() {
    }

    public static SpiritStorage read(ItemStack stack) {
        SpiritStorage storage = new SpiritStorage();
        CompoundTag tag = stack.getTag();
        if (tag != null && tag.contains(TAG_KEY)) {
            storage.readTag(tag.getCompound(TAG_KEY));
        }
        return storage;
    }

    public static SpiritStorage fromTag(CompoundTag tag) {
        SpiritStorage storage = new SpiritStorage();
        storage.readTag(tag);
        return storage;
    }

    private void readTag(CompoundTag tag) {
        for (int i = 0; i < TYPES.size(); i++) {
            counts[i] = tag.getInt(TYPES.get(i).identifier);
        }
    }

    public CompoundTag toTag() {
        CompoundTag tag = new CompoundTag();
        for (int i = 0; i < TYPES.size(); i++) {
            if (counts[i] > 0) {
                tag.putInt(TYPES.get(i).identifier, counts[i]);
            }
        }
        return tag;
    }

    public void write(ItemStack stack) {
        if (isEmpty()) {
            CompoundTag tag = stack.getTag();
            if (tag != null) {
                tag.remove(TAG_KEY);
            }
            return;
        }
        stack.getOrCreateTag().put(TAG_KEY, toTag());
    }

    public SpiritStorage copy() {
        SpiritStorage storage = new SpiritStorage();
        System.arraycopy(counts, 0, storage.counts, 0, counts.length);
        return storage;
    }

    public int get(MalumSpiritType type) {
        int index = TYPES.indexOf(type);
        return index < 0 ? 0 : counts[index];
    }

    public int total() {
        int total = 0;
        for (int count : counts) {
            total += count;
        }
        return total;
    }

    public boolean isEmpty() {
        return total() <= 0;
    }

    public float bonus(MalumSpiritType type) {
        float perGroup = type == SpiritTypeRegistry.UMBRAL_SPIRIT ? UMBRAL_BONUS_PER_GROUP : BONUS_PER_GROUP;
        return get(type) / (float) SPIRITS_PER_GROUP * perGroup;
    }

    public void add(MalumSpiritType type, int amount) {
        int index = TYPES.indexOf(type);
        if (index >= 0) {
            counts[index] += amount;
        }
    }

    public void addSpirits(List<ItemStack> spirits) {
        for (ItemStack stack : spirits) {
            for (MalumSpiritType type : TYPES) {
                if (stack.is(type.spiritShard.get())) {
                    add(type, stack.getCount());
                    break;
                }
            }
        }
    }

    public void absorb(SpiritStorage other) {
        for (int i = 0; i < counts.length; i++) {
            counts[i] += other.counts[i];
        }
    }
}