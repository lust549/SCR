package net.lust1212.lingzai_rebirth.common.item;

import com.sammy.malum.common.item.curiosities.TemporarilyDisabledItem;
import net.minecraft.world.item.Item;

public class SoulOfTheAnchorItem extends TemporarilyDisabledItem {
    public SoulOfTheAnchorItem(Item.Properties properties) {
        super(properties);
    }
}