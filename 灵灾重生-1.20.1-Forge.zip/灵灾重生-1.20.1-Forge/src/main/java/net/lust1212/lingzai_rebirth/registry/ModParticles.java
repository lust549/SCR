package net.lust1212.lingzai_rebirth.registry;

import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.minecraft.core.particles.ParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import team.lodestar.lodestone.systems.particle.world.type.LodestoneWorldParticleType;

public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, SpiritCalamityRebirth.MOD_ID);

    public static final RegistryObject<LodestoneWorldParticleType> ROUNDABOUT_SLASH = register("roundabout_slash");
    public static final RegistryObject<LodestoneWorldParticleType> THIN_ROUNDABOUT_SLASH = register("thin_roundabout_slash");
    public static final RegistryObject<LodestoneWorldParticleType> THIN_SLASH = register("thin_slash");
    public static final RegistryObject<LodestoneWorldParticleType> CHAOS_TARGET = register("chaos_target");
    public static final RegistryObject<LodestoneWorldParticleType> GIANT_ARROW = register("giant_arrow");

    private static RegistryObject<LodestoneWorldParticleType> register(String name) {
        return PARTICLES.register(name, LodestoneWorldParticleType::new);
    }
}