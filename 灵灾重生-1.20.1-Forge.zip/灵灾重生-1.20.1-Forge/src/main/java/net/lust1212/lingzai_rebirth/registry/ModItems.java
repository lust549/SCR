package net.lust1212.lingzai_rebirth.registry;

import com.sammy.malum.registry.common.item.ItemTiers;
import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.lust1212.lingzai_rebirth.common.item.SoulOfTheAnchorItem;
import net.lust1212.lingzai_rebirth.common.item.SunderingAnchorItem;
import net.lust1212.lingzai_rebirth.common.item.UnwindingChaosStaffItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SpiritCalamityRebirth.MOD_ID);

    public static final RegistryObject<Item> SUNDERING_ANCHOR = ITEMS.register("sundering_anchor",
            () -> new SunderingAnchorItem(ItemTiers.ItemTierEnum.MALIGNANT_ALLOY, 4.0f, new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> SOUL_OF_THE_ANCHOR = ITEMS.register("soul_of_the_anchor",
            () -> new SoulOfTheAnchorItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> UNWINDING_CHAOS = ITEMS.register("unwinding_chaos",
            () -> new UnwindingChaosStaffItem(ItemTiers.ItemTierEnum.AURIC_STAFF, 5.0f, 20, new Item.Properties().stacksTo(1)));
}