package net.lust1212.lingzai_rebirth.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.sammy.malum.client.RenderUtils;
import com.sammy.malum.registry.client.MalumRenderTypeTokens;
import com.sammy.malum.registry.common.SpiritTypeRegistry;
import net.lust1212.lingzai_rebirth.common.entity.FlyingSwordEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import team.lodestar.lodestone.registry.client.LodestoneRenderTypeRegistry;
import team.lodestar.lodestone.systems.rendering.VFXBuilders;

import java.awt.Color;

public class FlyingSwordRenderer extends EntityRenderer<FlyingSwordEntity> {

    private final ItemRenderer itemRenderer;

    public FlyingSwordRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.itemRenderer = context.getItemRenderer();
    }

    @Override
    public boolean shouldRender(FlyingSwordEntity entity, Frustum camera, double camX, double camY, double camZ) {
        return true;
    }

    @Override
    public void render(FlyingSwordEntity entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        float spin = entity.isAttacking() ? 0f : (entity.age + partialTicks) * 1.5f;
        poseStack.mulPose(Axis.YP.rotationDegrees(Mth.lerp(partialTicks, entity.yRotO, entity.getYRot()) + 90f + spin));
        if (entity.isAttacking()) {
            Vec3 motion = entity.getDeltaMovement();
            if (motion.lengthSqr() > 1.0E-4) {
                float pitch = (float) (-Mth.atan2(motion.y, motion.horizontalDistance()) * (180F / Math.PI));
                poseStack.mulPose(Axis.XP.rotationDegrees(Mth.clamp(pitch, -60f, 60f)));
            }
        }
        ItemStack stack = entity.getItem();
        var model = this.itemRenderer.getModel(stack, entity.level(), null, 1);
        itemRenderer.render(stack, ItemDisplayContext.FIXED, false, poseStack, buffer, packedLight, OverlayTexture.NO_OVERLAY, model);
        poseStack.popPose();

        float delta = Math.min(1f, entity.age / 8f);
        float scale = delta * 0.7f;
        float alpha = Mth.clamp(delta * 0.4f, 0, 1);
        var additive = LodestoneRenderTypeRegistry.ADDITIVE_TWO_SIDED_TEXTURE_TRIANGLE.applyAndCache(MalumRenderTypeTokens.CONCENTRATED_TRAIL);
        var transparent = LodestoneRenderTypeRegistry.TRANSPARENT_TWO_SIDED_TEXTURE_TRIANGLE.applyAndCache(MalumRenderTypeTokens.CONCENTRATED_TRAIL);
        VFXBuilders.WorldVFXBuilder builder = VFXBuilders.createWorld().setRenderType(additive);
        Color earthenPrimary = SpiritTypeRegistry.EARTHEN_SPIRIT.getPrimaryColor();
        Color earthenSecondary = SpiritTypeRegistry.EARTHEN_SPIRIT.getSecondaryColor();
        RenderUtils.renderEntityTrail(poseStack, builder, entity.trailPointBuilder, entity, earthenPrimary, earthenSecondary, scale * 1.2f, alpha * 0.4f, partialTicks);
        RenderUtils.renderEntityTrail(poseStack, builder, entity.spinningTrailPointBuilder, entity, earthenPrimary, earthenSecondary, scale * 2f, alpha, partialTicks);
        builder.setRenderType(transparent);
        Color aerialPrimary = SpiritTypeRegistry.AERIAL_SPIRIT.getPrimaryColor();
        Color aerialSecondary = SpiritTypeRegistry.AERIAL_SPIRIT.getSecondaryColor();
        RenderUtils.renderEntityTrail(poseStack, builder, entity.trailPointBuilder, entity, aerialPrimary, aerialSecondary, scale * 0.6f, alpha * 0.3f, partialTicks);
        RenderUtils.renderEntityTrail(poseStack, builder, entity.spinningTrailPointBuilder, entity, aerialPrimary, aerialSecondary, scale, alpha, partialTicks);

        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(FlyingSwordEntity entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}