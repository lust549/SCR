package net.lust1212.lingzai_rebirth.registry;

import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageType;

public class ModDamageTypes {
    public static final ResourceKey<DamageType> SUNDERING_ANCHOR_COMBO = key("sundering_anchor_combo");
    public static final ResourceKey<DamageType> SUNDERING_ANCHOR_MAGIC_COMBO = key("sundering_anchor_magic_combo");
    public static final ResourceKey<DamageType> PIERCING_STRIKE = key("piercing_strike");
    public static final ResourceKey<DamageType> ANCHOR_THROW_STRIKE = key("anchor_throw_strike");
    public static final ResourceKey<DamageType> ANCHOR_THROW_MAGIC_STRIKE = key("anchor_throw_magic_strike");
    public static final ResourceKey<DamageType> OVERLIMIT_STRIKE = key("overlimit_strike");
    public static final ResourceKey<DamageType> OVERLIMIT_MAGIC_STRIKE = key("overlimit_magic_strike");
    public static final ResourceKey<DamageType> SUPER_LIMIT_BREAK = key("super_limit_break");

    private static ResourceKey<DamageType> key(String name) {
        return ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(SpiritCalamityRebirth.MOD_ID, name));
    }

    public static void init() {
    }
}