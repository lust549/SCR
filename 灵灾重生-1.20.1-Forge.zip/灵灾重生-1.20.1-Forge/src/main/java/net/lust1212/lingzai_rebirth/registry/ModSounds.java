package net.lust1212.lingzai_rebirth.registry;

import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SpiritCalamityRebirth.MOD_ID);

    public static final RegistryObject<SoundEvent> SUNDERING_ANCHOR_SWING = register("sundering_anchor_swing");
    public static final RegistryObject<SoundEvent> SUNDERING_ANCHOR_EXTRA_SWING = register("sundering_anchor_extra_swing");
    public static final RegistryObject<SoundEvent> SUNDERING_ANCHOR_PROJECTILE_SWING = register("sundering_anchor_projectile_swing");

    public static final RegistryObject<SoundEvent> WORLDSOUL_MOTIF_LIGHT_IMPACT = register("worldsoul_motif_light_impact");
    public static final RegistryObject<SoundEvent> WORLDSOUL_MOTIF_HEAVY_IMPACT = register("worldsoul_motif_heavy_impact");
    public static final RegistryObject<SoundEvent> WORLDSOUL_MOTIF_REVERB = register("worldsoul_motif_reverb");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(SpiritCalamityRebirth.MOD_ID, name)));
    }
}