package net.lust1212.lingzai_rebirth.common.entity;

import com.sammy.malum.registry.common.SoundRegistry;
import com.sammy.malum.visual_effects.networked.data.ColorEffectData;
import net.lust1212.lingzai_rebirth.common.handler.SwordReturnHandler;
import net.lust1212.lingzai_rebirth.common.handler.UnstoppableDamageHandler;
import net.lust1212.lingzai_rebirth.common.item.SunderingAnchorItem;
import net.lust1212.lingzai_rebirth.registry.ModDamageTypes;
import net.lust1212.lingzai_rebirth.registry.ModEntities;
import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.lust1212.lingzai_rebirth.registry.ModMobEffects;
import net.lust1212.lingzai_rebirth.registry.ModParticleEffectTypes;
import net.lust1212.lingzai_rebirth.registry.ModParticles;
import net.lust1212.lingzai_rebirth.registry.ModSounds;
import net.lust1212.lingzai_rebirth.visual_effects.SunderingAnchorSweepParticleEffect;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import team.lodestar.lodestone.helpers.ColorHelper;
import team.lodestar.lodestone.helpers.DamageTypeHelper;
import team.lodestar.lodestone.helpers.RandomHelper;
import team.lodestar.lodestone.helpers.SoundHelper;
import team.lodestar.lodestone.registry.common.LodestoneAttributeRegistry;
import team.lodestar.lodestone.systems.rendering.trail.TrailPointBuilder;

import java.util.Comparator;

public class FlyingSwordEntity extends ThrowableItemProjectile {

    private enum SwordState {FORMATION, ATTACK}

    public static final int MAX_SWORDS = 5;
    private static final double SCAN_RADIUS = 12.0;
    private static final int SCAN_INTERVAL = 10;
    private static final int ATTACK_INTERVAL = 8;
    private static final double ATTACK_REACH = 2.4;
    private static final double MAX_CHASE_DISTANCE = 48.0;
    private static final double FORMATION_BACK = 1.5;
    private static final double FORMATION_UP = 1.4;
    private static final double FORMATION_SIDE = 0.7;
    private static final double FORMATION_SPREAD = 0.9;
    private static final double FORMATION_STAGGER = 0.35;
    private static final int FORMATION_REFRESH_INTERVAL = 10;

    private static final net.minecraft.network.syncher.EntityDataAccessor<Boolean> DATA_ATTACKING = net.minecraft.network.syncher.SynchedEntityData.defineId(FlyingSwordEntity.class, net.minecraft.network.syncher.EntityDataSerializers.BOOLEAN);

    public final TrailPointBuilder trailPointBuilder = TrailPointBuilder.create(60);
    public final TrailPointBuilder spinningTrailPointBuilder = TrailPointBuilder.create(8);
    public float spinOffset = (float) (Math.random() * Math.PI * 2);
    public int age;
    private int attackCooldown;
    private SwordState state = SwordState.FORMATION;
    private LivingEntity attackTarget;
    private int formationIndex;
    private int formationCount = 1;

    public FlyingSwordEntity(EntityType<? extends ThrowableItemProjectile> entityType, Level level) {
        super(entityType, level);
        noPhysics = true;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        getEntityData().define(DATA_ATTACKING, false);
    }

    public boolean isAttacking() {
        return getEntityData().get(DATA_ATTACKING);
    }

    private void setAttacking(boolean attacking) {
        getEntityData().set(DATA_ATTACKING, attacking);
    }

    public static FlyingSwordEntity summon(ServerPlayer owner, ItemStack stack) {
        FlyingSwordEntity sword = new FlyingSwordEntity(ModEntities.FLYING_SWORD.get(), owner.level());
        sword.setOwner(owner);
        sword.setItem(stack.copy());
        sword.setPos(owner.getX(), owner.getY() + owner.getBbHeight() * 0.8f, owner.getZ());
        owner.level().addFreshEntity(sword);
        return sword;
    }

    public static void giveBack(ServerPlayer player, ItemStack stack) {
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
        SoundHelper.playSound(player, SoundRegistry.SCYTHE_CATCH.get(), 0.5f, 1.2f);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.SUNDERING_ANCHOR.get();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag compound) {
        super.addAdditionalSaveData(compound);
        compound.putInt("age", age);
        compound.putString("swordState", state.name());
        compound.putInt("attackCooldown", attackCooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag compound) {
        super.readAdditionalSaveData(compound);
        age = compound.getInt("age");
        try {
            state = SwordState.valueOf(compound.getString("swordState"));
        } catch (IllegalArgumentException ignored) {
            state = SwordState.FORMATION;
        }
        attackCooldown = compound.getInt("attackCooldown");
    }

    @Override
    public void tick() {
        age++;
        if (level().isClientSide) {
            updateTrail();
            return;
        }
        ServerPlayer owner = getOwner() instanceof ServerPlayer player ? player : null;
        if (owner == null) {
            return;
        }
        if (!owner.isAlive() || owner.level() != level()) {
            returnItem(owner);
            return;
        }
        if (attackCooldown > 0) {
            attackCooldown--;
        }
        switch (state) {
            case FORMATION -> tickFormation(owner);
            case ATTACK -> tickAttack(owner);
        }
        setAttacking(state == SwordState.ATTACK);
    }

    private void tickFormation(ServerPlayer owner) {
        if (age % FORMATION_REFRESH_INTERVAL == 0) {
            refreshFormationPlacement(owner);
        }
        flyTowards(getFormationPos(owner), 0.9);
        if (age % SCAN_INTERVAL == 0) {
            LivingEntity target = findTarget(owner);
            if (target != null) {
                attackTarget = target;
                state = SwordState.ATTACK;
            }
        }
    }

    private void refreshFormationPlacement(ServerPlayer owner) {
        var swords = owner.level().getEntitiesOfClass(FlyingSwordEntity.class, owner.getBoundingBox().inflate(64),
                sword -> owner.equals(sword.getOwner()));
        swords.sort(Comparator.comparingInt(Entity::getId));
        formationCount = Math.max(1, swords.size());
        int index = swords.indexOf(this);
        formationIndex = Math.max(0, index);
    }

    private void tickAttack(ServerPlayer owner) {
        if (attackTarget == null || !attackTarget.isAlive() || attackTarget.level() != level() || distanceTo(attackTarget) > MAX_CHASE_DISTANCE) {
            attackTarget = null;
            state = SwordState.FORMATION;
            return;
        }
        Vec3 aim = attackTarget.position().add(0, attackTarget.getBbHeight() * 0.85, 0);
        flyTowards(aim, 1.35);
        if (distanceTo(attackTarget) <= ATTACK_REACH && attackCooldown <= 0) {
            performAttack(owner, attackTarget);
            attackCooldown = ATTACK_INTERVAL;
        }
    }

    private void performAttack(ServerPlayer owner, LivingEntity target) {
        if (!(level() instanceof ServerLevel serverLevel)) {
            return;
        }
        float proficiency = SunderingAnchorItem.getScytheProficiency(owner);
        float physical = (float) owner.getAttributeValue(Attributes.ATTACK_DAMAGE) * proficiency;
        float magic = (float) owner.getAttributeValue(LodestoneAttributeRegistry.MAGIC_DAMAGE.get()) * proficiency;
        target.invulnerableTime = 0;
        if (UnstoppableDamageHandler.hasOverlimit(getItem())) {
            UnstoppableDamageHandler.forcePierce(target,
                    UnstoppableDamageHandler.createStrikeSource(serverLevel, getItem(), ModDamageTypes.OVERLIMIT_STRIKE, this, owner),
                    UnstoppableDamageHandler.breakAmount(getItem(), physical));
            if (magic > 0 && target.isAlive()) {
                UnstoppableDamageHandler.forcePierce(target,
                        UnstoppableDamageHandler.createStrikeSource(serverLevel, getItem(), ModDamageTypes.OVERLIMIT_MAGIC_STRIKE, this, owner),
                        UnstoppableDamageHandler.breakAmount(getItem(), magic));
            }
        } else {
            boolean success = target.hurt(DamageTypeHelper.create(level(), ModDamageTypes.SUNDERING_ANCHOR_COMBO, this, owner), physical);
            if (!success) {
                return;
            }
            if (magic > 0) {
                target.invulnerableTime = 0;
                target.hurt(DamageTypeHelper.create(level(), ModDamageTypes.SUNDERING_ANCHOR_MAGIC_COMBO, this, owner), magic);
            }
        }
        SunderingAnchorItem.applyHatred(target);
        SoundHelper.playSound(this, ModSounds.SUNDERING_ANCHOR_SWING.get(), 1.5f, RandomHelper.randomBetween(level().random, 0.9f, 1.3f));
        var spirit = SunderingAnchorItem.getSunderingAnchorSpirit();
        Vec3 slashDirection = target.position().subtract(position()).normalize();
        ModParticleEffectTypes.SUNDERING_ANCHOR_SLASH.createEntityEffect(target,
                new ColorEffectData(spirit),
                net.lust1212.lingzai_rebirth.visual_effects.SunderingAnchorSlashParticleEffect.createData(
                        slashDirection, random.nextBoolean(), random.nextFloat() * 6.28f, 3));
        ModParticleEffectTypes.SUNDERING_ANCHOR_SWEEP.createEntityEffect(target,
                new ColorEffectData(spirit), SunderingAnchorSweepParticleEffect.createData(spirit));
    }

    private void flyTowards(Vec3 targetPos, double speed) {
        Vec3 diff = targetPos.subtract(position());
        if (diff.lengthSqr() < 1.0E-5) {
            setDeltaMovement(getDeltaMovement().scale(0.6));
            return;
        }
        Vec3 desired = diff.normalize().scale(Math.min(speed, diff.length()));
        setDeltaMovement(getDeltaMovement().lerp(desired, 0.35));
        setPos(position().add(getDeltaMovement()));
        Vec3 motion = getDeltaMovement();
        if (motion.horizontalDistanceSqr() > 1.0E-5) {
            setYRot((float) (Mth.atan2(motion.x, motion.z) * (180F / Math.PI)) - 90F);
            yRotO = getYRot();
        }
    }

    private Vec3 getFormationPos(ServerPlayer owner) {
        Vec3 flatLook = new Vec3(owner.getLookAngle().x, 0, owner.getLookAngle().z);
        if (flatLook.lengthSqr() < 1.0E-4) {
            flatLook = new Vec3(0, 0, 1);
        }
        flatLook = flatLook.normalize();
        Vec3 side = new Vec3(-flatLook.z, 0, flatLook.x);
        float centered = formationIndex - (formationCount - 1) / 2f;
        double spreadOffset = centered * FORMATION_SPREAD;
        double backExtra = Math.abs(centered) * FORMATION_STAGGER;
        double bob = Math.sin(age * 0.12 + formationIndex) * 0.12;
        double sway = Math.sin(age * 0.06) * FORMATION_SIDE * 0.2;
        return owner.position()
                .subtract(flatLook.scale(FORMATION_BACK + backExtra))
                .add(side.scale(spreadOffset + sway))
                .add(0, owner.getBbHeight() * 0.6 + FORMATION_UP * 0.35 + bob + (formationIndex % 2) * 0.25, 0);
    }

    private LivingEntity findTarget(ServerPlayer owner) {
        var targets = level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(SCAN_RADIUS), entity -> isValidTarget(owner, entity));
        return targets.stream().min(Comparator.comparingDouble(entity -> entity.distanceToSqr(this))).orElse(null);
    }

    private boolean isValidTarget(ServerPlayer owner, LivingEntity entity) {
        if (entity == owner || !entity.isAlive() || entity.isDeadOrDying()) {
            return false;
        }
        if (entity.isAlliedTo(owner)) {
            return false;
        }
        if (entity instanceof TamableAnimal tamable && tamable.isTame()) {
            return false;
        }
        return !(entity instanceof Player player) || player.hasEffect(ModMobEffects.HATRED.get());
    }

    private void returnItem(ServerPlayer owner) {
        ItemStack stack = getItem().copy();
        if (owner.isAlive()) {
            giveBack(owner, stack);
        } else {
            SwordReturnHandler.storePendingReturn(owner.getUUID(), stack);
        }
        discard();
    }

    @OnlyIn(Dist.CLIENT)
    private void updateTrail() {
        Vec3 direction = getDeltaMovement();
        if (direction.lengthSqr() > 1.0E-6) {
            Vec3 projectileDirection = direction.normalize();
            float yRot = ((float) (Mth.atan2(projectileDirection.x, projectileDirection.z) * (double) (180F / (float) Math.PI)));
            float yaw = (float) Math.toRadians(yRot);
            Vec3 left = new Vec3(-Math.cos(yaw), 0, Math.sin(yaw));
            Vec3 up = left.cross(projectileDirection);
            float offsetScale = 0.3f;
            for (int i = 0; i < 2; i++) {
                float progress = (i + 1) * 0.5f;
                Vec3 position = getPosition(progress);
                float scalar = (age + progress) / 2f;
                double xOffset = Math.cos(spinOffset + scalar) * offsetScale;
                double zOffset = Math.sin(spinOffset + scalar) * offsetScale;
                trailPointBuilder.addTrailPoint(position);
                spinningTrailPointBuilder.addTrailPoint(position.add(left.scale(xOffset)).add(up.scale(zOffset)));
            }
        }
        trailPointBuilder.tickTrailPoints();
        spinningTrailPointBuilder.tickTrailPoints();
        spawnParticles();
    }

    @OnlyIn(Dist.CLIENT)
    private void spawnParticles() {
        Level level = level();
        float scalar = Math.min(1f, age / 8f);
        Vec3 norm = getDeltaMovement().normalize().scale(0.05f);
        var spirit = SunderingAnchorItem.getSunderingAnchorSpirit();
        var lightSpecs = com.sammy.malum.visual_effects.SpiritLightSpecs.spiritLightSpecs(level, position(), spirit);
        lightSpecs.getBuilder()
                .setRenderTarget(team.lodestar.lodestone.handlers.RenderHandler.LATE_DELAYED_RENDER)
                .multiplyLifetime(5f)
                .setMotion(norm);
        lightSpecs.getBloomBuilder()
                .setRenderTarget(team.lodestar.lodestone.handlers.RenderHandler.LATE_DELAYED_RENDER)
                .multiplyLifetime(5f)
                .setMotion(norm);
        lightSpecs.spawnParticles();
        final java.util.function.Consumer<team.lodestar.lodestone.systems.particle.world.LodestoneWorldParticle> behavior =
                p -> p.setParticleSpeed(p.getParticleSpeed().scale(0.95f));

        float count = 1 + (float) getDeltaMovement().length() * 3;
        for (int i = 0; i < count; i++) {
            spirit = SunderingAnchorItem.getSunderingAnchorSpirit();
            Vec3 particlePos = getPosition(i / count);
            team.lodestar.lodestone.systems.particle.builder.WorldParticleBuilder.create(ModParticles.ROUNDABOUT_SLASH,
                            new com.sammy.malum.client.PointyDirectionalBehaviorComponent(getDeltaMovement().normalize()))
                    .setTransparencyData(team.lodestar.lodestone.systems.particle.data.GenericParticleData.create(0.9f * scalar, 0.7f * scalar, 0f)
                            .setEasing(team.lodestar.lodestone.systems.easing.Easing.SINE_IN_OUT, team.lodestar.lodestone.systems.easing.Easing.SINE_IN).build())
                    .setSpinData(team.lodestar.lodestone.systems.particle.data.spin.SpinParticleData.createRandomDirection(random, RandomHelper.randomBetween(random, 0.25f, 0.5f)).randomSpinOffset(random).build())
                    .setScaleData(team.lodestar.lodestone.systems.particle.data.GenericParticleData.create(0.2f * scalar, 0.4f * scalar)
                            .setEasing(team.lodestar.lodestone.systems.easing.Easing.SINE_IN_OUT).build())
                    .setSpritePicker(team.lodestar.lodestone.systems.particle.SimpleParticleOptions.ParticleSpritePicker.WITH_AGE)
                    .setRenderTarget(team.lodestar.lodestone.handlers.RenderHandler.LATE_DELAYED_RENDER)
                    .setColorData(spirit.createColorData().build())
                    .setLifetime(Math.min(5 + age * 2, 20))
                    .addTickActor(behavior)
                    .enableForcedSpawn()
                    .enableNoClip()
                    .spawn(level, particlePos.x, particlePos.y, particlePos.z)
                    .setScaleData(team.lodestar.lodestone.systems.particle.data.GenericParticleData.create(0.3f * scalar, 0.5f * scalar)
                            .setEasing(team.lodestar.lodestone.systems.easing.Easing.SINE_IN_OUT).build())
                    .setTransparencyData(team.lodestar.lodestone.systems.particle.data.GenericParticleData.create(0.6f * scalar, 0.5f * scalar, 0f)
                            .setEasing(team.lodestar.lodestone.systems.easing.Easing.SINE_IN_OUT, team.lodestar.lodestone.systems.easing.Easing.SINE_IN).build())
                    .setRenderType(team.lodestar.lodestone.systems.particle.render_types.LodestoneWorldParticleRenderType.LUMITRANSPARENT)
                    .setColorData(team.lodestar.lodestone.systems.particle.data.color.ColorParticleData.create(ColorHelper.darker(spirit.getPrimaryColor(), 2)).build())
                    .spawn(level, particlePos.x, particlePos.y, particlePos.z);
        }
    }

    @Override
    public boolean isNoGravity() {
        return true;
    }

    @Override
    public float getPickRadius() {
        return 1.5f;
    }

    @Override
    public boolean fireImmune() {
        return true;
    }

    @Override
    public boolean ignoreExplosion() {
        return true;
    }
}