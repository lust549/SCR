package net.lust1212.lingzai_rebirth.registry;

import com.sammy.malum.visual_effects.networked.ParticleEffectType;
import net.lust1212.lingzai_rebirth.visual_effects.EntropicBoltImpactParticleEffect;
import net.lust1212.lingzai_rebirth.visual_effects.SunderingAnchorSlashParticleEffect;
import net.lust1212.lingzai_rebirth.visual_effects.SunderingAnchorSweepParticleEffect;
import net.lust1212.lingzai_rebirth.visual_effects.UnwindingChaosChargeParticleEffect;

public class ModParticleEffectTypes {
    public static ParticleEffectType SUNDERING_ANCHOR_SLASH;
    public static ParticleEffectType SUNDERING_ANCHOR_SWEEP;
    public static ParticleEffectType ENTROPIC_BOLT_IMPACT;
    public static ParticleEffectType UNWINDING_CHAOS_CHARGE;

    public static void init() {
        if (SUNDERING_ANCHOR_SLASH == null) {
            SUNDERING_ANCHOR_SLASH = new SunderingAnchorSlashParticleEffect("sundering_anchor_slash");
            SUNDERING_ANCHOR_SWEEP = new SunderingAnchorSweepParticleEffect("sundering_anchor_sweep");
            ENTROPIC_BOLT_IMPACT = new EntropicBoltImpactParticleEffect("entropic_bolt_impact");
            UNWINDING_CHAOS_CHARGE = new UnwindingChaosChargeParticleEffect("unwinding_chaos_charge");
        }
    }
}