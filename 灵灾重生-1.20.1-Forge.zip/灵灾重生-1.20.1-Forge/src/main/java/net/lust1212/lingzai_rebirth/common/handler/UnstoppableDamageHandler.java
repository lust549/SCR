package net.lust1212.lingzai_rebirth.common.handler;

import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.lust1212.lingzai_rebirth.registry.ModDamageTypes;
import net.lust1212.lingzai_rebirth.registry.ModEnchantments;
import net.lust1212.lingzai_rebirth.registry.ModItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.ShieldBlockEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import team.lodestar.lodestone.helpers.DamageTypeHelper;

import java.util.IdentityHashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = SpiritCalamityRebirth.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class UnstoppableDamageHandler {

    private static final Map<LivingHurtEvent, Float> HURT_AMOUNTS = new IdentityHashMap<>();
    private static final Map<LivingDamageEvent, Float> DAMAGE_AMOUNTS = new IdentityHashMap<>();

    public static final float SUPER_LIMIT_DAMAGE = 9_999_999f;

    public static boolean isThrowDamage(DamageSource source) {
        return source.is(ModDamageTypes.ANCHOR_THROW_STRIKE) || source.is(ModDamageTypes.ANCHOR_THROW_MAGIC_STRIKE);
    }

    public static boolean isOverlimitDamage(DamageSource source) {
        return source.is(ModDamageTypes.OVERLIMIT_STRIKE)
                || source.is(ModDamageTypes.OVERLIMIT_MAGIC_STRIKE)
                || source.is(ModDamageTypes.SUPER_LIMIT_BREAK);
    }

    public static boolean hasOverlimit(ItemStack stack) {
        return stack.is(ModItems.SUNDERING_ANCHOR.get())
                && (stack.getEnchantmentLevel(ModEnchantments.OVERLIMIT.get()) > 0
                || stack.getEnchantmentLevel(ModEnchantments.SUPER_LIMIT_BREAK.get()) > 0);
    }

    public static boolean hasSuperLimitBreak(ItemStack stack) {
        return stack.is(ModItems.SUNDERING_ANCHOR.get())
                && stack.getEnchantmentLevel(ModEnchantments.SUPER_LIMIT_BREAK.get()) > 0;
    }

    public static float breakAmount(ItemStack stack, float base) {
        return hasSuperLimitBreak(stack) ? SUPER_LIMIT_DAMAGE : base;
    }

    /**
     * Sourceless damage source for anchors bearing Super Limit Break, a regular typed source otherwise.
     */
    public static DamageSource createStrikeSource(ServerLevel level, ItemStack stack, ResourceKey<DamageType> type, Entity direct, Entity attacker) {
        if (hasSuperLimitBreak(stack)) {
            return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ModDamageTypes.SUPER_LIMIT_BREAK));
        }
        return DamageTypeHelper.create(level, type, direct, attacker);
    }

    /**
     * Damage that must never be intercepted: the baseline throw strikes plus every strike
     * issued while the anchor carries the Overlimit enchantment.
     */
    public static boolean shouldDominate(DamageSource source) {
        return isThrowDamage(source) || isOverlimitDamage(source) || isOverlimitSwing(source);
    }

    private static boolean isOverlimitSwing(DamageSource source) {
        Entity direct = source.getDirectEntity();
        return direct instanceof Player player && hasOverlimit(player.getMainHandItem());
    }

    /**
     * Call hurt() first; if it fails (entity immune), fall back to a forced strike.
     */
    public static boolean hurt(LivingEntity target, DamageSource source, float amount) {
        if (amount <= 0 || !target.isAlive()) {
            return false;
        }
        target.invulnerableTime = 0;
        boolean success = target.hurt(source, amount);
        if (!success && shouldDominate(source)) {
            forcePierce(target, source, amount);
            return true;
        }
        return success;
    }

    /**
     * Fully aggressive strike: bypasses every mitigation and never calls hurt().
     */
    public static void forcePierce(LivingEntity target, DamageSource source, float amount) {
        applyForceDamage(target, amount);
        if (target.getHealth() <= 0f) {
            target.die(source);
        }
    }

    /**
     * Applies the strike without triggering death, for callers running inside hurt():
     * the vanilla flow finishes afterwards and settles the death exactly once.
     */
    public static void forcePierceNoDeath(LivingEntity target, float amount) {
        applyForceDamage(target, amount);
    }

    private static void applyForceDamage(LivingEntity target, float amount) {
        if (amount <= 0 || !target.isAlive()) {
            return;
        }
        target.invulnerableTime = 0;
        float remaining = amount;
        float absorption = target.getAbsorptionAmount();
        if (absorption > 0) {
            float absorbed = Math.min(absorption, remaining);
            target.setAbsorptionAmount(absorption - absorbed);
            remaining -= absorbed;
        }
        if (remaining > 0) {
            target.setHealth(Math.max(0f, target.getHealth() - remaining));
        }
    }

    /**
     * Rewrites the amount recorded for an event, so later handlers cannot lift it back up.
     */
    public static void overrideAmount(LivingHurtEvent event, float amount) {
        HURT_AMOUNTS.replace(event, amount);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onPlayerAttackTarget(AttackEntityEvent event) {
        if (!hasOverlimit(event.getEntity().getMainHandItem())) {
            return;
        }
        if (event.getTarget() instanceof LivingEntity living) {
            living.invulnerableTime = 0;
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onAttackApply(LivingAttackEvent event) {
        if (!shouldDominate(event.getSource())) {
            return;
        }
        event.setCanceled(false);
        event.getEntity().invulnerableTime = 0;
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onShieldBlock(ShieldBlockEvent event) {
        if (shouldDominate(event.getDamageSource())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onHurtCapture(LivingHurtEvent event) {
        if (shouldDominate(event.getSource())) {
            HURT_AMOUNTS.put(event, event.getAmount());
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onHurtApply(LivingHurtEvent event) {
        if (!shouldDominate(event.getSource())) {
            return;
        }
        Float amount = HURT_AMOUNTS.remove(event);
        event.setCanceled(false);
        if (amount != null) {
            event.setAmount(amount);
        }
        event.getEntity().invulnerableTime = 0;
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onDamageCapture(LivingDamageEvent event) {
        if (shouldDominate(event.getSource())) {
            DAMAGE_AMOUNTS.put(event, event.getAmount());
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onDamageApply(LivingDamageEvent event) {
        if (!shouldDominate(event.getSource())) {
            return;
        }
        Float amount = DAMAGE_AMOUNTS.remove(event);
        event.setCanceled(false);
        if (amount != null) {
            event.setAmount(amount);
        }
    }
}