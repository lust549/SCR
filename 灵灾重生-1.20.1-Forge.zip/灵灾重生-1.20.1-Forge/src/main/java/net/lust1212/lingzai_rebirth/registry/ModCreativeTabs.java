package net.lust1212.lingzai_rebirth.registry;

import net.lust1212.lingzai_rebirth.SpiritCalamityRebirth;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SpiritCalamityRebirth.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.lingzai_rebirth"))
                    .icon(() -> new ItemStack(ModItems.SUNDERING_ANCHOR.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.SUNDERING_ANCHOR.get());
                        output.accept(ModItems.UNWINDING_CHAOS.get());
                        output.accept(ModItems.SOUL_OF_THE_ANCHOR.get());
                    })
                    .build());

    public static final RegistryObject<CreativeModeTab> SPECIAL_ENCHANTMENTS = TABS.register("special_enchantments",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.lingzai_rebirth.special_enchantments"))
                    .icon(() -> createEnchantedBook(ModEnchantments.WANJIAN_GUIZONG.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(createEnchantedBook(ModEnchantments.WANJIAN_GUIZONG.get()));
                        output.accept(createEnchantedBook(ModEnchantments.FISSION.get()));
                        output.accept(createEnchantedBook(ModEnchantments.PIERCING.get()));
                        output.accept(createEnchantedBook(ModEnchantments.GATHER.get()));
                        output.accept(createEnchantedBook(ModEnchantments.VIOLENCE.get()));
                        output.accept(createEnchantedBook(ModEnchantments.KINETIC_ACCELERATION.get()));
                        output.accept(createEnchantedBook(ModEnchantments.SPIRIT_STORAGE.get()));
                        output.accept(createEnchantedBook(ModEnchantments.OVERLIMIT.get()));
                        output.accept(createEnchantedBook(ModEnchantments.SUPER_LIMIT_BREAK.get()));
                    })
                    .build());

    private static ItemStack createEnchantedBook(net.minecraft.world.item.enchantment.Enchantment enchantment) {
        ItemStack stack = new ItemStack(net.minecraft.world.item.Items.ENCHANTED_BOOK);
        EnchantedBookItem.addEnchantment(stack, new EnchantmentInstance(enchantment, enchantment.getMaxLevel()));
        return stack;
    }
}